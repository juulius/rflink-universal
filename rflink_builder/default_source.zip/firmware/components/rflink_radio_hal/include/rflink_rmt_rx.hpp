#pragma once
#include <cstddef>
#include <cstdint>
#include <array>
#include <mutex>
#include "esp_err.h"
#include "driver/rmt_rx.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "rflink_rf_profiles.hpp"
#include "rflink_rx_sink.hpp"

namespace rflink {
// RMT captures raw pulses, NEVER decodes protocols. No TX, no rolling-code state.
// Owner: RadioManager -> RmtPulseRx; no other component may attach to these GDO2 pins.
// Stable numeric diagnostic stages exposed through the local status API.
// 0=none, 1=queue, 2=channel, 3=GPIO pull, 4=callbacks,
// 5=enable, 6=initial receive, 7=receive rearm.
enum class RmtRxFailureStage : uint8_t { none, queue, channel, gpio_pull, callbacks, enable, arm, rearm };
struct PulseStats {
  bool listening=false;
  uint32_t captures=0;
  uint32_t symbols=0;
  uint32_t queue_drops=0;
  uint32_t driver_errors=0;
  int32_t last_driver_error=0;
  RmtRxFailureStage last_driver_stage=RmtRxFailureStage::none;
  uint32_t short_frames=0; // legacy aggregate: fewer than two RAW durations + saturated captures
  uint32_t full_frames=0; // RMT host buffer saturated/truncated, NOT successfully decoded RF frames
  uint32_t filtered_frames=0; // >= 2 pulses before filter, < 2 after 30us filter
  uint32_t forwarded_frames=0; // actually delivered to the native decoder
  uint32_t last_symbols=0;
  uint32_t last_raw_pulses=0; // Signed GDO2 durations copied before any software filtering.
  uint32_t last_filtered_pulses=0; // Post-30us count, excluding the synthetic 5ms idle tail; 0 if not filtered.
  uint32_t last_full_symbols=0; // Last full/incomplete capture, even after later valid RX.
  uint32_t last_forwarded_pulses=0; // Survived software filtering and sent to decoder.
  uint32_t capture_capacity_symbols=512; // Host RMT receive buffer, NOT mem_block_symbols.
  uint8_t last_capture_outcome=0; // 0=forwarded,1=short,2=full,3=filtered.
};
class RmtPulseRx {
public:
  RmtPulseRx()=default;
  ~RmtPulseRx();
  RmtPulseRx(const RmtPulseRx&)=delete;
  RmtPulseRx& operator=(const RmtPulseRx&)=delete;
  esp_err_t start(RadioId radio);
  esp_err_t stop();
  // Poll only completed, separately owned buffers; RMT is already rearmed by
  // the ISR before the worker decodes anything. Never access the active slot.
  void poll_once();
  void set_frame_sink(RxFrameSink* sink) { sink_ = sink; }
  // Optional worker-only evidence tap: exact RMT durations before the 30us
  // software filter / synthetic idle tail. Never called from the RMT ISR.
  // stage 0=complete candidate, 1=short, 2=full/incomplete.
  using CaptureObserver=void (*)(void*,RadioId,const int32_t*,size_t,uint16_t,uint8_t);
  void set_capture_observer(CaptureObserver fn,void* context){
    capture_observer_=fn;capture_context_=context;
  }
  PulseStats stats() const;
  RadioId radio() const {return radio_;}
private:
  static bool IRAM_ATTR on_rx_done(rmt_channel_handle_t, const rmt_rx_done_event_data_t*, void*);
  esp_err_t IRAM_ATTR arm();
  void release_queues();
  // Non-DMA RMT hardware memory stays 96 symbols. The receive target is a
  // separate host-owned buffer: 256 was repeatedly saturated on 433.92 MHz.
  // 512 is a conservative diagnostic increase; never claim it handles
  // arbitrarily long frames or silently forward a truncated capture.
  static constexpr size_t kMaxSymbols=512;
  // One RMT-owned capture slot plus two slots for completed recordings.
  // Bounded internal RAM, independent from PSRAM log/detail buffers.
  static constexpr size_t kCaptureSlots=3;
  rmt_symbol_word_t symbols_[kCaptureSlots][kMaxSymbols]{};
  // Keep scratch off the 8 KiB FreeRTOS RX worker stack. It is owned by the
  // receiver and never accessed by the ISR or HTTP task.
  std::array<int32_t,kMaxSymbols*2> scratch_{};
  rmt_channel_handle_t channel_=nullptr;
  QueueHandle_t done_=nullptr;
  QueueHandle_t free_slots_=nullptr;
  // Accessed only at startup (after RMT disable) or in RMT on_recv_done ISR.
  uint8_t active_slot_isr_=0;
  // RMT hardware glitch filter, clamped to the actual RMT source clock.
  // The 30us RF pulse filter is applied separately after capture.
  uint32_t hardware_filter_ns_=0;
  // Precomputed in start(); ISR rearm never builds configuration on its stack.
  rmt_receive_config_t receive_config_{};
  RadioId radio_=RadioId::rf43342;
  RxFrameSink* sink_ = nullptr;
  CaptureObserver capture_observer_=nullptr;
  void* capture_context_=nullptr;
  mutable std::mutex stats_mutex_;
  PulseStats stats_{};
  // The ESP32-S3 toolchain does not guarantee std::atomic<uint32_t> is
  // lock-free. Use a short SMP FreeRTOS spinlock, never the std::mutex in ISR.
  // Both the ISR writer and task reader hold this same dedicated mux.
  mutable portMUX_TYPE queue_drop_mux_=portMUX_INITIALIZER_UNLOCKED;
  uint32_t queue_drops_isr_=0;
  int32_t rearm_error_isr_=0; // recorded in ISR, consumed by RX task
};
} // namespace rflink
