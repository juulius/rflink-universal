/* Native Radioactive web app. No ESPHome runtime and no legacy RFLink REST calls.
 * All radio actions are read-only in this stage; never simulate pairing or TX.
 */
'use strict';
const $=id=>document.getElementById(id);
const pages=[...document.querySelectorAll('.page')];
const nav=[...document.querySelectorAll('[data-page]')];
const radioNames=['433.42 MHz','433.92 MHz','868.30 MHz'];
let currentPage='status', lastStatus=null, lastEvents=[], logSource='all';
let consoleConnected=false, consoleCursor=0, consoleBootId=null, consoleBusy=false;
let statusBusy=false, logsBusy=false, historyBusy=false;
let logPageCursors=[0],logSnapshot=0,logHasOlder=false,logLivePaused=false;
const webPages=['status','devices','logs','learn','diagnostics','settings'];
const webActions=['page_open','log_source','log_radio','log_noise','log_expand',
  'log_collapse','log_export','log_older','log_newer','log_latest',
  'console_connect','console_disconnect','console_clear','diagnostics_refresh',
  'settings_submit','led_submit','ota_confirm','ota_result','api_client_error',
  'radio_inspect'];
const webEndpoints=['/api/status','/api/diagnostics/crashes','/api/diagnostics/console',
  '/api/logs','/api/logs.csv','/api/logs/config','/api/logs/ui','/api/led',
  '/api/events','/api/events.csv','/api/mqtt/status','/api/mqtt/config',
  '/api/ota','/setup','/api/radio/capture'];
const webErrorTimes=new Map();
function auditUi(action,value=0,endpoint=0){
  if(!webActions.includes(action)||!webPages.includes(currentPage))return;
  // Only predefined action/page IDs reach RFLink. Never transmit form contents,
  // captured RF data, passwords, OTA filenames or request URL queries.
  fetch('/api/logs/ui',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({action,page:currentPage,value,endpoint}),keepalive:true})
    .catch(()=>{}); // Logging must never block primary UI actions.
}
function auditApiFailure(path,status){
  const route=String(path).split('?')[0];
  const endpoint=webEndpoints.indexOf(route)+1;
  const key=endpoint+':'+status, now=Date.now();
  if(now-(webErrorTimes.get(key)||0)<60000)return;
  webErrorTimes.set(key,now);
  auditUi('api_client_error',status,endpoint);
}
function resetLogPages(){
  logPageCursors=[0];logSnapshot=0;logHasOlder=false;logLivePaused=false;
  expandedLogKeys.clear();
  $('log-latest').textContent='Latest events';
}
let nextErrorShown=false,otaUploading=false;
const fmt=n=>typeof n==='number'&&Number.isFinite(n)?n.toLocaleString():'—';
const yesNo=v=>v===true?'Yes':v===false?'No':'—';
const hexByte=n=>Number.isInteger(n)&&n>=0&&n<=255?
  '0x'+n.toString(16).toUpperCase().padStart(2,'0'):'—';
// DD.HH.MM.SS shows duration since boot, not clock time.
const uptime=seconds=>{
  if(!Number.isFinite(seconds)||seconds<0)return '—';
  const s=Math.floor(seconds),d=Math.floor(s/86400);
  const h=Math.floor((s%86400)/3600),m=Math.floor((s%3600)/60);
  return [d,h,m,s%60].map(n=>String(n).padStart(2,'0')).join('.');
};
const uptimeMs=milliseconds=>{
  if(!Number.isFinite(milliseconds)||milliseconds<0)return '—';
  const ms=Math.floor(milliseconds),sec=Math.floor(ms/1000);
  const day=Math.floor(sec/86400),hour=Math.floor((sec%86400)/3600);
  const min=Math.floor((sec%3600)/60);
  const pad=n=>String(n).padStart(2,'0');
  return (day?day+'d ':'')+pad(hour)+':'+pad(min)+':'+pad(sec%60)+
    ','+String(ms%1000).padStart(3,'0');
};
const bytes=n=>Number.isFinite(n)&&n>=0?
  (n>=1048576?(n/1048576).toFixed(2)+' MB':
    n>=1024?(n/1024).toFixed(1)+' KB':Math.round(n)+' B'):'—';
function markStatus(el,label,level){
  el.textContent=label;
  el.classList.remove('online','offline','warn');
  if(level)el.classList.add(level);
}
function showPage(page){
  if(!pages.some(p=>p.dataset.view===page))return;
  currentPage=page;
  auditUi('page_open');
  for(const section of pages)section.classList.toggle('active',section.dataset.view===page);
  for(const item of nav){
    const active=item.dataset.page===page;
    item.classList.toggle('active',active);
    if(active)item.setAttribute('aria-current','page');
    else item.removeAttribute('aria-current');
  }
  if(page==='logs')refreshLogs();
  if(page==='diagnostics'){refreshHistory();pollConsole();}
  if(page==='settings')refreshSettings();
  if(page==='status')refreshEvents();
  if(page!=='diagnostics')disconnectConsole();
  window.scrollTo(0,0);
}
for(const item of nav)item.addEventListener('click',()=>showPage(item.dataset.page));
for(const item of document.querySelectorAll('[data-goto]'))
  item.addEventListener('click',()=>showPage(item.dataset.goto));
async function api(path,options={}){
  // Only fixed native same-origin API paths. The browser never calls the old
  // ESPHome /rflink/api paths and never sends credentials in the URL.
  if(!path.startsWith('/api/'))throw new Error('Unsupported API path');
  let response;
  try{response=await fetch(path,{cache:'no-store',...options});}
  catch{auditApiFailure(path,0);throw new Error('Cannot reach RFLink over the network');}
  if(!response.ok){
    auditApiFailure(path,response.status);
    throw new Error('RFLink HTTP '+response.status);
  }
  try{return await response.json();}
  catch{auditApiFailure(path,0);throw new Error('RFLink returned invalid JSON');}
}
function offline(error){
  markStatus($('top-state'),'Offline','offline');
  $('side-connection').textContent='RFLink not responding';
  $('side-dot').classList.remove('online');$('side-dot').classList.add('offline');
  $('system-health').textContent='Not reachable';
  $('system-hint').textContent=error.message;
  renderOtaReadiness(null);
  if(!nextErrorShown){console.warn('Native RFLink status unavailable:',error.message);nextErrorShown=true;}
}
function renderStatus(s){
  lastStatus=s;
  nextErrorShown=false;
  renderLogCaptureDiagnostics();
  const connected=s.wifi_connected===true;
  const initialized=s.radio_initialized===true;
  const complete=s.startup_complete===true;
  markStatus($('top-state'),complete?'Online':initialized?'Initializing':'Starting',complete?'online':'warn');
  $('side-connection').textContent=complete?'Device online':'Firmware starting';
  $('side-dot').classList.remove('offline');$('side-dot').classList.add('online');
  $('system-health').textContent=complete?'Running':'Starting up';
  $('system-hint').textContent=complete?'Application startup finished; RF performance not yet verified':
    'Network diagnostics may be available before radio initialization';
  $('firmware-version').textContent=s.firmware||'Unknown';
  $('firmware-meta').textContent=(s.release_channel||'Native')+
    (Number.isInteger(s.release_build)?' · build '+s.release_build:'');
  $('version-pill').textContent=s.firmware_display||s.firmware||'Native v0.7';
  $('side-version').textContent=s.firmware||'v0.7 native ESP-IDF';
  $('settings-firmware').textContent=(s.firmware_display||s.firmware||'Unknown firmware')+
    ' · '+(s.board_id||'Unknown board');
  $('radio-count').textContent=initialized?(s.cc1101_present||[]).filter(Boolean).length+' / 3':'— / 3';
  $('radio-hint').textContent=initialized?'SPI-probed CC1101 modules':'Radio probing not complete';
  const ready=[s.rx43342_listening===true,s.rx43392_listening===true,s.rx868_listening===true]
    .map((listening,i)=>listening&&s.cc1101_present?.[i]===true&&
      s.cc1101_spi_healthy?.[i]===true);
  $('rx-count').textContent=initialized?ready.filter(Boolean).length+' / 3':'— / 3';
  // Only recognized receive events count as dashboard messages.
  // Older firmware lacks the per-radio message counters: show unavailable,
  // never substitute continuous bit blocks, RMT captures or FIFO reads.
  const frames=s.rx_messages||[];
  const candidates=s.rx_raw_candidates||[];
  const a868=s.rx868_activity;
  const activity=[s.rx43342_frames,s.rx43392_frames,a868?.samples>0?a868.bursts:null];
  for(let i=0;i<3;i++){
    const present=initialized&&Array.isArray(s.cc1101_present)?s.cc1101_present[i]===true:false;
    const label=!initialized?'Starting':!present?'Not detected':ready[i]?'Listening':'RX inactive';
    markStatus($('radio-status-'+i),label,!initialized?'warn':!present?'offline':ready[i]?'online':'warn');
    $('radio-hw-'+i).textContent=!initialized?'Checking':present?'Detected':'Missing';
    $('radio-frames-'+i).textContent=initialized&&Number.isSafeInteger(frames[i])?fmt(frames[i]):'—';
    $('radio-candidates-'+i).textContent=initialized&&Number.isSafeInteger(candidates[i])?fmt(candidates[i]):'—';
    $('radio-activity-'+i).textContent=initialized&&Number.isSafeInteger(activity[i])?fmt(activity[i]):'—';
    $('radio-spi-'+i).textContent=initialized?fmt((s.spi_ready_timeouts||[])[i]):'—';
    $('diag-cc1101-'+i).textContent=!initialized?'Probing not complete':
      (present?'Detected':'Not detected')+
      ' · SPI '+(s.cc1101_spi_healthy?.[i]===true?'healthy':'unavailable')+
      ' · PARTNUM '+hexByte(s.cc1101_partnum?.[i])+
      ' · VERSION '+hexByte(s.cc1101_version?.[i])+
      ' · boot readback '+(s.cc1101_boot_readback_verified?.[i]===true?'passed':'not verified');
  }
  $('info-ip').textContent=s.ipv4||'Not assigned';
  $('info-wifi').textContent=connected?'Connected':'Not connected';
  $('info-mqtt').textContent=s.mqtt_connected?'Connected':'Not connected';
  renderUptimeWithBoot(s);
  $('info-clock').textContent=s.clock_synced?
    (localTimestamp(s.now_utc_ms)||'Synchronizing')+' · NTP':
    'Awaiting NTP (uptime available)';
  $('info-heap').textContent=bytes(s.free_heap_bytes);
  $('diag-memory-uptime').textContent='Uptime '+uptime(s.uptime_s);
  for(const kind of ['internal','psram']){
    const total=s[kind+'_total_bytes'],free=s[kind+'_free_bytes'];
    const available=Number.isFinite(total)&&total>0&&Number.isFinite(free);
    const base='memory-'+kind+'-';
    $(base+'used').textContent=available?
      bytes(Math.max(0,total-free))+' / '+bytes(total)+' ('+
        Math.round((total-free)/total*100)+'% used)':'Not available';
    $(base+'free').textContent=available?bytes(free):'—';
    $(base+'min').textContent=available?bytes(s[kind+'_min_free_bytes']):'—';
    $(base+'largest').textContent=available?bytes(s[kind+'_largest_block_bytes']):'—';
  }
  renderOtaReadiness(s);
  $('settings-wifi').textContent=connected?'Connected':'Not connected';
  const failed=initialized&&ready.some((listening,i)=>s.cc1101_present?.[i]===true&&!listening);
  $('warning-summary').textContent=!initialized?'Radio initialization in progress':
    failed?'At least one detected radio is not listening. Open Diagnostics for detail.':
    'No receiver startup warning reported. RF on-air reception still needs validation.';
  $('warning-summary').classList.toggle('warn',Boolean(failed));
}
async function refreshStatus(){
  if(statusBusy)return;
  statusBusy=true;
  try{renderStatus(await api('/api/status'));}
  catch(error){offline(error);}
  finally{statusBusy=false;}
}
function renderRecent(events){
  const target=$('recent-events');target.replaceChildren();
  const rows=events.slice(-6).reverse();
  if(!rows.length){const p=document.createElement('p');p.className='subtle small';
    p.textContent='No decoded RF activity captured yet.';target.append(p);return;}
  for(const e of rows){
    const row=document.createElement('div');row.className='event-row';
    const label=document.createElement('span');
    label.textContent=(radioNames[e.radio]||'RF')+' · '+String(e.kind||'Event');
    const time=document.createElement('small');time.textContent=uptimeMs(e.uptime_ms)+' uptime';
    row.append(label,time);target.append(row);
  }
}
async function refreshEvents(){
  try{const r=await api('/api/events');lastEvents=Array.isArray(r.events)?r.events:[];renderRecent(lastEvents);}
  catch{$('recent-events').textContent='Receiver event feed temporarily unavailable.';}
}
// RMT capture counts are NOT the number of decoded/logged pulse trains.
// Expose each stage to troubleshoot "frames increase but no logs" without
// spamming the shared noise ring or touching the receive interrupt.
function renderReceiverEvidence(){
  const s=lastStatus;
  if(!s)return;
  const details=['43342','43392'].map(id=>{
    const prefix='rx'+id+'_';
    if(!Number.isFinite(s[prefix+'frames']))return id+' telemetry unavailable';
    const channel=id==='43342'?'433.42':'433.92';
    return channel+' MHz: '+fmt(s[prefix+'frames'])+' captures, '+
      fmt(s[prefix+'forwarded_frames'])+' forwarded, '+
      fmt(s[prefix+'full_frames'])+' RMT buffers saturated (not decoded frames), '+
      fmt(s[prefix+'queue_drops'])+' completion queue losses, last full '+
      fmt(s[prefix+'last_full_symbols'])+'/'+
      fmt(s[prefix+'capture_capacity'])+' RMT symbols'+
      (Number.isFinite(s[prefix+'last_forwarded_pulses'])?
       ', last forwarded '+fmt(s[prefix+'last_forwarded_pulses'])+' pulses':'');
  });
  const userStates=['Empty','Loaded','Recovered (read-only)','Invalid NVS snapshots','NVS read error'];
  const userCode=Number(s.user_library_storage_state);
  const userInfo='User RX recipes: '+fmt(s.user_decoders_enabled)+
    ' enabled · '+fmt(s.user_rx_matches)+' matches · '+
    fmt(s.user_rx_ambiguous)+' conflicts · storage '+
    (userStates[userCode]||'Not available')+
    '. Matching does not save or authorize a device.';
  $('diag-rx433-summary').textContent=details.join(' · ')+' · '+userInfo;
  const prefix=Number(s.decode_unknown_prefix),unrecognized=Number(s.decode_unknown_payload);
  if(s.rx868_sync_mode===true){
    $('diag-rx868-summary').textContent='868.30 MHz · synchronous DATA+CLOCK (Experimental): '+
      fmt(s.rx868_sync_edges)+' sampled clock bits · '+
      fmt(s.rx868_sync_blocks)+' processed bit blocks (not packets) · '+
      fmt(s.rx868_sync_itho_candidates)+' Itho structural candidates (unverified) · '+
      fmt(s.rx868_sync_ramses_valid)+' RAMSES-II checksum matches ('+
      fmt(s.rx868_sync_embedded)+' nested in Itho) · '+
      fmt(s.rx868_sync_queue_drops)+' decoder queue drops · '+
      fmt(s.rx868_sync_discontinuities)+' discontinuities · '+
      fmt(s.rx868_sync_scan_errors)+' parser errors. '+
      (s.rx868_activity?.samples>0?
        'RF activity: '+fmt(s.rx868_activity.bursts)+' observed periods ('+
        fmt(s.rx868_activity.partial_starts)+' partial starts) · '+
        fmt(s.rx868_activity.samples)+' samples · '+
        fmt(s.rx868_activity.missed_samples)+' missed · '+
        fmt(s.rx868_activity.gap_resets)+' gap resets · max gap '+
        (Number(s.rx868_activity.max_gap_us)/1000).toFixed(1)+' ms · max SPI read '+
        fmt(s.rx868_activity.max_read_us)+' µs · RSSI '+
        (Number.isFinite(s.rx868_activity.rssi_dbm_x2)?(s.rx868_activity.rssi_dbm_x2/2).toFixed(1)+' dBm':'unavailable')+
        ' · RSSI range '+(s.rx868_activity.min_rssi_dbm_x2/2).toFixed(1)+' to '+
        (s.rx868_activity.max_rssi_dbm_x2/2).toFixed(1)+' dBm · carrier '+
        (s.rx868_activity.carrier===null?'unavailable':s.rx868_activity.carrier?'high':'low')+'. ':
        'RF activity sampling unavailable or awaiting first sample. ')+
      (s.rx868_sync_decoder_running===false
        ? 'LIVE DECODER NOT RUNNING: check memory/task allocation in the system console.'
        : 'Native live decoder running. Clock activity is live telemetry, not a decoded packet; signal logs contain classified candidates only.');
    return;
  }
  $('diag-rx868-summary').textContent='868.30 MHz: '+
    fmt(s.rx868_packets)+' fixed-length FIFO reads · '+
    fmt((s.decode_itho||0)+(s.decode_ramses||0))+' decoded protocol messages · '+
    (Number.isFinite(prefix)?fmt(prefix):'—')+' preamble mismatches · '+
    (Number.isFinite(unrecognized)?fmt(unrecognized):'—')+
    ' preamble matched but undecoded · '+fmt(s.rx868_fifo_overflows)+
    ' FIFO overflows. CRC validation is disabled in this profile.';
}
function renderLogCaptureDiagnostics(){
  renderReceiverEvidence();
  const node=$('log-capture-diagnostics');
  const selected=$('log-radio').value;
  const radioView=logSource==='radio'||logSource==='all';
  const syncView=radioView&&selected==='2'&&lastStatus?.rx868_sync_mode===true;
  const inspect=radioView&&(selected==='0'||selected==='1');
  node.hidden=!(inspect||syncView);
  if(syncView){
    // Reuse boot-total receiver telemetry; no extra log rows or API polling.
    node.textContent=$('diag-rx868-summary').textContent+
      ' · Live activity, refreshed with device status; separate from the frozen RAW recording.';
    return;
  }
  if(!inspect)return;
  const radio=selected==='0'?'43342':'43392';
  const display=selected==='0'?'433.42 MHz':'433.92 MHz';
  const s=lastStatus;
  if(!s || !Number.isFinite(s['rx'+radio+'_forwarded_frames'])){
    node.textContent=display+': RMT capture-to-decoder counters not available on this firmware. '+
      'Install the updated firmware to see why frames were discarded.';
    return;
  }
  const name='rx'+radio+'_';
  const capture=s[name+'frames'],forwarded=s[name+'forwarded_frames'],
    full=s[name+'full_frames'],filtered=s[name+'filtered_frames'],
    short=s[name+'short_frames'];
  const tooShort=Math.max(0,short-full);
  const decoded=s['decode_pulses_'+radio];
  node.textContent=display+': '+fmt(capture)+' RMT captures · '+
    fmt(forwarded)+' forwarded to decoder · '+fmt(decoded)+
    ' decoder pulse inputs (not protocol matches) · '+fmt(tooShort)+' truly short · '+
    fmt(full)+' saturated/incomplete RMT buffers (capacity '+
    fmt(s[name+'capture_capacity']||256)+' symbols; last full '+
    fmt(s[name+'last_full_symbols'])+' symbols) · '+
    fmt(s[name+'queue_drops'])+' completion queue losses · '+fmt(filtered)+
    ' discarded after 30 µs filter. '+
    (Number.isFinite(s[name+'last_raw_pulses'])?
      'Last raw capture: '+fmt(s[name+'last_raw_pulses'])+
      ' signed durations, '+fmt(s[name+'last_filtered_pulses'])+
      ' after filtering (0 if no filter pass). '+
      'Unknown RAW candidates (6+ original and decoder-input pulses; complete capture) are retained in their own per-band capture ring, separate from recognized 433 MHz messages and shared 868 MHz noise. Tiny glitches remain in shared noise (enable Include noise). '+
      'RMT capture completion does not prove a valid RF protocol message.':
      (!$('log-noise').checked?
        'Raw 433 MHz events are classified as noise: enable Include noise to see them.':
        'If no rows appear, the shared noise ring may have overwritten older events; select this frequency and export CSV to check retained records.'));
}
function selectedLogQuery(paging=false){
  const p=new URLSearchParams(),radio=$('log-radio').value,noise=$('log-noise').checked;
  if(['system','web'].includes(logSource))p.set('stream',logSource);
  else if(logSource==='radio')p.set('view','radio');
  if(['radio','all'].includes(logSource)&&radio)p.set('radio',radio);
  if(noise&&['all','radio'].includes(logSource))p.set('noise','1');
  if(paging){
    if(logSnapshot)p.set('snapshot',String(logSnapshot));
    if(logPageCursors[logPageCursors.length-1])
      p.set('before',String(logPageCursors[logPageCursors.length-1]));
  }
  return p;
}
function eventIsVisible(event){
  if(logSource==='radio'&&!['noise','signal'].includes(event.stream) &&
    !(event.stream==='system'&&[11,12,13,35,36,37,43,44,45].includes(event.code)))return false;
    if(logSource==='system'&&event.stream!=='system')return false;
  if(logSource==='web'&&event.stream!=='web')return false;
  if(!$('log-noise').checked&&event.stream==='noise')return false;
  return true;
}
// The log ring carries sanitized metadata, not the original RF packet bytes.
// 433 capture summary: 0=forwarded; 1=short; 2=saturated; 3=filtered; 4=queue full.
const rxCaptureReasons=['forwarded to decoder','too short','RMT buffer saturated',
  'discarded by 30 µs pulse filter','RMT completion queue full'];
const expandedLogKeys=new Set();
// Keep the current log snapshot fixed while someone is inspecting expanded
// details. Logging continues on the ESP32; only this browser's live view pauses.
function pauseLogViewing(){
  if(logPageCursors.length!==1||logLivePaused)return;
  logLivePaused=true;
  $('log-latest').disabled=false;
  $('log-latest').textContent='Resume live';
  $('log-page-number').textContent='Page 1 · paused';
  $('log-feedback').textContent=
    'Viewing paused — new events are still recorded. Select Resume live to catch up.';
}
const txTransportNames=['Packet FIFO','RMT','UART'];
const txErrorNames=['None','Invalid radio','No hardware','Busy','Incompatible profile',
  'Missing profile','Unsupported transport','Driver failure','Invalid payload',
  'TX failure','RX restore failure'];
const txStageNames=['None','Unsupported','Snapshot','Modem','GPIO UART','Enter TX',
  'UART write','UART drain','FIFO write','FIFO wait','RMT configuration',
  'RMT send','RMT wait','Restore','RX pause'];
function logRowKey(e){return String(e.stream||'unknown')+'-'+String(e.sequence);}
const webActionNames=['Page opened','Log source changed','Radio filter changed','Noise visibility changed',
  'Log expanded','Log collapsed','CSV export requested','Older logs requested',
  'Newer logs requested','Latest logs requested','Console connected',
  'Console disconnected','Console cleared','Diagnostics refreshed',
  'Logging settings submitted','LED settings submitted','OTA installation confirmed',
  'OTA result reported','Browser API error','Radio logs inspected'];
const readableWebPage=n=>webPages[n-1]||'Unknown page';
const readableWebEndpoint=n=>webEndpoints[n-1]||'Unknown API endpoint';
const readableWebAction=n=>webActionNames[n-1]||'Unknown UI action';
function readableWebActionValue(e){
  // Action IDs and numeric values are defined by the native v0.7 audit
  // endpoint, never by user-supplied strings.
  if(e.code!==39)return '';
  if(e.count===2){
    const names=['All','Radio','Noise (legacy)','System','Web'];
    return names[e.value]?' · '+names[e.value]:'';
  }
  if(e.count===3){
    const frequencies=['All radios','433.42 MHz','433.92 MHz','868.30 MHz'];
    return frequencies[e.value]?' · '+frequencies[e.value]:'';
  }
  if(e.count===4)return e.value===1?' · noise shown':' · noise hidden';
  if(e.count>=8&&e.count<=10)return ' · page '+String(e.value);
  return '';
}
function logDetails(e){
  if(e.code===5)return String(e.count??0)+' RF units · RX recipe matched (not an enrolled device)';
  if(e.code===6)return String(e.count??0)+' RF units · multiple user recipes matched; no device chosen';
  if(e.code===2)return String(e.count??0)+' bytes · '+
    (e.value===1?'Supported Itho/RAMSES preamble absent':
     e.value===2?'Preamble present; both decoders rejected packet':
     'Unknown packet reason (older firmware)');
  if(e.code===51)return fmt(e.value)+' sampled DATA+CLOCK bits · '+
    fmt(e.count)+' processed blocks in ~30 seconds · NOT decoded RF frames';
  if(e.code===52 || e.code===53){
    const grade=e.code===52?'Itho structural only; NOT checksum verified':
      'RAMSES-II native checksum valid; physical reception still experimental';
    const types=['Unknown','Speed','Timer','Fan speed','Humidity','RAMSES command'];
    const type=types[e.profile]||'Unknown message';
    return grade+' · '+e.count+' bits · '+
      type+' '+(e.profile===5?'0x'+Number(e.value).toString(16).toUpperCase():e.value)+
      (Number(e.flags)&1?' · inverted polarity hypothesis':'')+
      (Number(e.flags)&2?' · overlaps another logical decode':'');
  }
  if(e.code===55)return fmt(e.count)+' exact clocked bits · alternating preamble candidate · not a complete message';
  if(e.code===54)return fmt(e.count)+' completed bit block(s) dropped before decode · '+
    fmt(e.value)+' discontinuity markers (cumulative)';
  if(e.code===35)return String(e.count??0)+' capture(s) in ~30 s · '+
    (rxCaptureReasons[e.value]||'unknown outcome')+
    ' · aggregate counter, not a linked RF message';
  if(e.code===46)return String(e.count??0)+' raw pulse durations · '+
    (e.value===2?'incomplete 512-symbol buffer':
     Number(e.count)<=2?'1–2 durations; no reliable protocol decode':e.value===5?'too few usable durations':e.value===3?'filtered / no decoder input':e.stream==='noise'?'noise / incomplete':'unknown candidate')+
    ' · '+String(e.profile??'?')+' RMT symbols · expand to inspect/export';
  if(e.code===36)return 'PARTNUM '+hexByte((Number(e.count)>>8)&255)+
    ' · VERSION '+hexByte(Number(e.count)&255)+
    ' · boot readback '+((Number(e.flags)&1)?'passed':'not verified')+
    ' · result '+(e.value===0?'OK':String(e.value??'unknown'));
  if(e.code===37)return 'Three consecutive SPI identity checks failed; radio marked offline';
  if(e.code===38)return 'Opened '+readableWebPage(e.profile);
  if(e.code===39 || e.code===42)return readableWebAction(e.count)+
    readableWebActionValue(e)+' · '+readableWebPage(e.profile)+
    (e.code===42?' · HTTP '+e.value:'');
  if(e.code===40 || e.code===41)return ((Number(e.flags)&1)?'POST ':'GET ')+
    readableWebEndpoint(e.count)+
    ' · HTTP '+e.value;
  if(e.code===43)return 'RX started successfully';
  if(e.code===44)return 'RX stopped for recovery';
  if(e.code===45)return 'RX start failed · driver status '+e.value;
  const parts=[];
  if(e.code>=1&&e.code<=4 && Number.isFinite(e.count))
    parts.push(e.count+(e.code===1?' pulses':' bytes'));
  else if(e.count)parts.push(e.count+' items');
  if(e.code===4 && Number.isInteger(e.value)&&e.value>0)
    parts.push('RAMSES command 0x'+e.value.toString(16).toUpperCase().padStart(4,'0'));
  if(e.correlation_id)parts.push(e.code>=1&&e.code<=6?
    'RX capture #'+e.correlation_id:'TX #'+e.correlation_id);
  if(e.code>=30&&e.code<=34){
    if(e.profile!==undefined)parts.push('profile '+e.profile);
    if(e.tx_driver_attempted)parts.push('driver '+(e.tx_driver_accepted?'accepted (RF unverified)':'failed'));
    if(e.tx_rx_previous)parts.push('RX '+(e.tx_rx_restored?'restored':'NOT restored'));
  }else if(e.value && e.code!==4)parts.push('status '+e.value);
  return parts.length?parts.join(' · '):'—';
}
function logEventTitle(e){
  if(e.code===46&&(Number(e.flags)&128))return e.stream==='noise'?'Noise / incomplete capture':'Unknown RF signal';
  if(e.code===38)return 'Page opened · '+readableWebPage(e.profile);
  if(e.code===39 || e.code===42)return readableWebAction(e.count);
  if(e.code===40)return 'API failed · '+readableWebEndpoint(e.count);
  if(e.code===41)return 'API updated · '+readableWebEndpoint(e.count);
  return String(e.kind||'Unknown event');
}
// Keep monotonic uptime primary: the NTP boot timestamp is an optional
// human-readable second line, never a substitute for device uptime.
function renderUptimeWithBoot(status){
  const node=$('info-uptime');
  node.replaceChildren(document.createTextNode(uptime(status.uptime_s)));
  const boot=Number.isInteger(status.boot_id)&&status.boot_id>0?
    ' · boot #'+status.boot_id:'';
  const bootTime=status.clock_synced===true?
    localTimestamp(status.boot_started_utc_ms):null;
  const hint=document.createElement('small');
  hint.className='uptime-boot-hint';
  hint.textContent=(bootTime?'Started '+bootTime+' (local)':
    'Start time unknown · awaiting NTP')+boot;
  node.append(hint);
}
function localTimestamp(epochMs){
  const value=Number(epochMs);
  if(!Number.isFinite(value)||value<1704067200000||value>=4102444800000)return null;
  return new Date(value).toLocaleString('nl-NL',{
    year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',
    minute:'2-digit',second:'2-digit',hour12:false
  })+','+String(Math.floor(value%1000)).padStart(3,'0');
}
function logMetadataFields(e){
  const code=Number(e.code);
  const unified=Number(e.radio)<2&&!!(Number(e.flags)&128);
  const isRx=code>=1&&code<=8, isSyncCandidate=code===52||code===53,
    isTx=code>=30&&code<=34;
  const severity=['Info','Warning','Error'][e.severity]||'Unknown';
  const fields=[
    ['Date/time',localTimestamp(e.timestamp_utc_ms)||'Unknown · awaiting SNTP'],
    ['Uptime',uptimeMs(e.uptime_ms)+' (raw '+String(e.uptime_ms??'—')+' ms)'],
    ['Sequence','#'+String(e.sequence??'—')],
    ['Source',String(e.stream||'—')],['Severity',severity],
    ['Event',String(e.kind||'Unknown')+' (code '+String(e.code??'—')+')']
  ];
  if(Number.isInteger(e.radio)&&e.radio>=0&&e.radio<radioNames.length)
    fields.push(['Radio',radioNames[e.radio]]);
  if(code===55){
    fields.push(['Detection','Alternating preamble heuristic; not a validated RF frame']);
    fields.push(['Captured sample',String(e.count??0)+' clocked bits, fixed window (MSB first)']);
    fields.push(['Retention','Isolated 868 RAW buffer; expand this row to inspect the retained bits']);
  }else if(isSyncCandidate){
    const types=['Unknown','Speed','Timer','Fan percent','Humidity percent','RAMSES command'];
    fields.push(['Validation',code===52?
      'Itho structurally plausible; NOT CRC/physical-radio validated':
      'RAMSES-II checksummed native codec; radio path still experimental']);
    fields.push(['Bit span',String(e.count??0)+' sampled bits']);
    fields.push(['Interpretation',types[e.profile]||'Unknown']);
    fields.push(['Value',e.profile===5?'0x'+Number(e.value).toString(16).toUpperCase():
      String(e.value??'Unknown')]);
    fields.push(['Polarity',(Number(e.flags)&1)?'Inverted candidate':'Normal']);
    fields.push(['Overlap',(Number(e.flags)&2)?'Overlapping logical data':'No overlapping match']);
    fields.push(['Raw capture','No direct capture link; inspect separate RAW candidate rows or a manual frozen capture']);
    fields.push(['Device action','None; automatic control/learning remains disabled']);
  }else if(isRx){
    fields.push([(code===1 || (code>=5&&code<=8&&Number(e.radio)<2))?'Pulse count':'Packet length',
      String(e.count??'—')+((code===1 || (code>=5&&code<=8&&Number(e.radio)<2))?' pulses':' bytes')]);
    if(code===4){
      fields.push(['Protocol','RAMSES-II']);
      fields.push(['Command',Number.isInteger(e.value)&&e.value>0?
        '0x'+e.value.toString(16).toUpperCase().padStart(4,'0')+' ('+e.value+')':
        'Not decoded']);
    }else if(code===5||code===6){
      fields.push(['Recognition',code===5?'A user RX recipe matched':'Multiple user RX recipes matched']);
      fields.push(['Device status','Not enrolled; RX only; no RF TX authorization']);
      fields.push(['Decision',code===6?'Ambiguous: no device selected':'Recipe accepted; no unique device claim']);
    }else if(code===7||code===8){
      fields.push(['Protocol',code===7?'Acurite 609TXC':'Fine Offset WH2']);
      fields.push(['Recognition','Native weather decoder matched']);
    }else if(code===3){
      fields.push(['Protocol','Itho']);
      fields.push(['Command','Not recorded in the native event ring']);
    }else{
      fields.push(['Recognition',code===1?'Raw pulse input':'Unknown packet']);
      if(code===2){
        fields.push(['Why unknown',e.value===1?'Supported preamble absent':
          e.value===2?'Preamble present, neither decoder accepted':
          'Reason unavailable in older firmware']);
        fields.push(['CRC / LQI','Not validated by current 868 fixed-length modem profile']);
      }
    }
    fields.push(['Decoder overlap',(Number(e.flags)&1)?'Yes':'No']);
    fields.push(['Raw RF capture',unified?'Original capture #'+e.sequence+'; expand for exact sampled durations':e.correlation_id?
      'Linked capture #'+e.correlation_id+'; expand this row for the volatile GDO2 timings or FIFO bytes':
      'No linked raw capture in this firmware']);
    fields.push(['Retention',unified?'Bounded per-band original waveform storage':'Existing bounded radio PSRAM detail buffer; fallback keeps 8 samples if detail storage is unavailable']);
  }else if(isTx){
    fields.push(['TX correlation ID',e.correlation_id?'#'+e.correlation_id:'Not assigned']);
    fields.push(['Profile',String(e.profile??'—')]);
    fields.push(['Transport',txTransportNames[e.tx_transport]||'Unknown / not selected']);
    fields.push(['TX units',String(e.count??'—')]);
    fields.push(['Repeats',String(e.tx_repeats??'—')]);
    fields.push(['Failure stage',txStageNames[e.tx_stage]||'Unknown']);
    fields.push(['Driver status',e.tx_driver_attempted?
      (e.tx_driver_accepted?'Accepted by driver (not RF verification)':'Rejected or failed'):
      'Not attempted']);
    fields.push(['RX before TX',e.tx_rx_previous?'Active':'Inactive']);
    fields.push(['RX restoration',e.tx_rx_restored?'Restored':'Not reported restored']);
    fields.push(['Hardware restoration',e.tx_hardware_restored?'Restored':'Not reported restored']);
    fields.push(['Result code',txErrorNames[e.value]||String(e.value??'—')]);
    fields.push(['RF on-air confirmation','Not available from the driver trace']);
  }else if(code===36){
    fields.push(['PARTNUM',hexByte((Number(e.count)>>8)&255)]);
    fields.push(['VERSION',hexByte(Number(e.count)&255)]);
    fields.push(['Boot-only CHANNR readback',(Number(e.flags)&1)?'Passed':'Not verified (or not performed)']);
    fields.push(['SPI result code',String(e.value??'—')]);
    fields.push(['Meaning','An identity response is not proof of RF reception']);
  }else if(code===37){
    fields.push(['Cause','Three consecutive read-only SPI identity checks failed']);
    fields.push(['Action','RX capture stopped; hardware unavailable; automatic re-probe scheduled']);
  }else if(code===38||code===39||code===42){
    fields.push(['Browser page',readableWebPage(e.profile)]);
    fields.push(['User action',readableWebAction(e.count)]);
    if(e.value)fields.push(['Action value / HTTP status',String(e.value)]);
    if(code===42)fields.push(['API',readableWebEndpoint(e.tx_transport)]);
    fields.push(['Privacy','Only predefined action IDs are stored, never inputs or passwords']);
  }else if(code===40||code===41){
    fields.push(['HTTP method',(Number(e.flags)&1)?'POST':'GET']);
    fields.push(['API endpoint',readableWebEndpoint(e.count)]);
    fields.push(['HTTP status',String(e.value)]);
    fields.push(['Privacy','Request content, URL query, headers and secrets are not logged']);
  }else if(code===43||code===44||code===45){
    fields.push(['Receiver action',code===43?'Started':code===44?'Stopped':'Driver failed']);
    fields.push(['Driver error',String(e.value??'—')]);
  }else if(code===46){
    fields.push(['Capture phase','Before the 30µs software filter; exact sampled GDO2 levels']);
    fields.push(['RMT symbols',String(e.profile??'—')]);
    fields.push(['Duration count',String(e.count??'—')]);
    fields.push(['Capture outcome',e.value===2?'Full/incomplete; cannot decode as a whole frame':
      e.value===1?'Too short':e.value===3?'Filtered / no decoder input':e.value===5?'Too few usable durations':'Complete capture (protocol not yet validated)']);
    fields.push(['Metadata retention',e.stream==='signal'?
      'Dedicated 433 MHz capture ring: does not evict recognized RF messages':
      'Shared noise ring: original details sampled; may be unavailable']);
    fields.push(['Exact durations','Expand to inspect retained signed µs values; noise details are sampled']);
    if(Number(e.count)<=2)
      fields.push(['Why no decoded message','One or two durations cannot establish reliable bits, a frame or a device; exact µs remain useful for diagnosis']);
  }else if(code===35){
    fields.push(['Outcome',rxCaptureReasons[e.value]||'Unknown']);
    fields.push(['Occurrences in the previous ~30 s',String(e.count??0)]);
    if(Number(e.value)===2){
      fields.push(['Meaning','Capture reached the RMT host buffer limit and was discarded as incomplete. Could be a long signal or continuous RF noise.']);
      const id=Number(e.radio)===0?'43342':'43392';
      fields.push(['Current buffer limit',String(lastStatus?.['rx'+id+'_capture_capacity']??'Unknown')+' RMT symbols (current status, not event-time data)']);
    }
    if(Number(e.value)===4)fields.push(['Meaning','The RX callback could not queue a completion. No complete pulse frame was delivered.']);
    fields.push(['Data source','RMT capture-stage counters only, NOT an individual RF packet or capture ID']);
    fields.push(['Where to inspect actual signal','Select Radio → 433.42/433.92 MHz; inspect RAW RMT capture rows (code 46). Enable Include noise for rejected or incomplete captures; expand RAW events for signed µs values']);
  }else if(e.value!==undefined){
    fields.push(['Status / error code',String(e.value)]);
  }
  if(unified){
    fields.push(['Original durations',String(e.count??0)]);
    fields.push(['Decoder-input durations (including idle tail)',String(e.rx_decoder_count??0)]);
    fields.push(['Capture result',e.stream==='noise'?'Noise / incomplete':code===46||code===6?'Unknown or ambiguous':'Recognized']);
    fields.push(['Evidence','One original waveform; decoder input is not stored a second time. Noise details are sampled.']);
  }
  return fields;
}
// Radio details use isolated, bounded per-category PSRAM FIFO stores.
// Cache on-demand snapshots for this browser page only; never send RF
// packet bytes, rolling codes or GDO2 timings to UI-audit/System/Web logging.
const rawCaptureRequests=new Map();
async function populateRawCapture(node){
  const radio=Number(node.dataset.rawRadio),seq=Number(node.dataset.rawSeq);
  if(!Number.isSafeInteger(radio)||radio<0||radio>2||
     !Number.isSafeInteger(seq)||seq<1)return;
  const pre=node.dataset.rawPre==='1',sync=node.dataset.rawSync==='1';
  const key=radio+':'+seq+':'+(sync?'sync':pre?'pre':'decoded');
  if(!rawCaptureRequests.has(key)){
    if(rawCaptureRequests.size>40)rawCaptureRequests.clear();
    rawCaptureRequests.set(key,api('/api/radio/capture?radio='+radio+'&seq='+seq+
      (sync?'&sync=1':pre?'&pre=1':''))
      .catch(error=>({available:false,reason:error.message})));
  }
  const frame=await rawCaptureRequests.get(key);
  if(!node.isConnected)return;
  if(!frame.available){
    node.textContent='Raw capture unavailable ('+String(frame.reason||'overwritten')+
      '). Details are retained in the isolated PSRAM FIFO until overwritten or reboot.';
    return;
  }
  const hash=Number.isInteger(frame.hash)?
    ' · RF hash '+frame.hash.toString(16).toUpperCase().padStart(8,'0'):'';
  if(frame.format==='signed_pulses_us'&&Array.isArray(frame.pulses_us)){
    const highs=frame.pulses_us.filter(x=>x>0);
    const lows=frame.pulses_us.filter(x=>x<0).map(x=>-x);
    const periods=[];
    for(let i=0;i+1<frame.pulses_us.length;++i)
      if(frame.pulses_us[i]>0&&frame.pulses_us[i+1]<0)
        periods.push(frame.pulses_us[i]-frame.pulses_us[i+1]);
    const mostCommon=values=>{
      const histogram=new Map();
      for(const width of values) {
        const bucket=Math.round(width/50)*50;
        histogram.set(bucket,(histogram.get(bucket)||0)+1);
      }
      return [...histogram].sort((a,b)=>b[1]-a[1]).slice(0,6)
        .map(([width,count])=>width+'µs ×'+count).join(' · ')||'none';
    };
    node.textContent=(pre?'GDO2 PRE-FILTER capture':'GDO2 decoded-input capture')+
      ' · '+frame.pulses_us.length+' signed pulse durations · '+frame.frequency_hz+hash+
      ' Hz\nHigh: '+highs.length+' · Low: '+lows.length+
      '\nPulse widths (high; 50µs bins): '+mostCommon(highs)+
      '\nGap widths (low; 50µs bins): '+mostCommon(lows)+
      '\nPulse periods (high + next gap): '+mostCommon(periods)+
      '\nExact signed pulse durations (µs; positive=high, negative=low):\n'+
      frame.pulses_us.join(', ')+
      (pre?'\nPre-filter physical capture; may be noise or an incomplete RF frame.':
        '\nPost-filter decoder input, possibly including synthetic 5ms idle tail.')+
      '\nThese are GDO2 timings, NOT decoded bytes; no protocol claimed.';
  }else if(frame.format==='clocked_bits_hex'&&typeof frame.hex==='string'){
    node.textContent='868 RAW candidate · '+frame.bit_count+' clocked bits (MSB first) · '+frame.frequency_hz+hash+
      ' Hz\n'+frame.hex+'\nFixed evidence window; not a validated complete RF message.';
  }else if(frame.format==='fifo_bytes_hex'&&typeof frame.hex==='string'){
    node.textContent='CC1101 FIFO capture · '+frame.count+' bytes · '+frame.frequency_hz+hash+
      ' Hz\n'+frame.hex+
      (Number.isFinite(frame.rssi_dbm)&&Number.isFinite(frame.lqi)&&
       Number.isFinite(frame.frequency_offset_hz)?
        '\nRSSI '+frame.rssi_dbm.toFixed(1)+' dBm · LQI '+frame.lqi+
        ' (lower is better) · FREQEST '+frame.frequency_offset_hz+' Hz':
        '\nRSSI / LQI / frequency offset unavailable for this capture')+
      '\nBytes are unverified RF input; CRC is disabled and packet length is not protocol proof.';
  }else node.textContent='Raw capture format not recognized on this firmware.';
}
// System/Web/TX use the same on-demand detail mechanism without fetching RF
// contents, HTTP bodies, secrets or a complete log history.
const diagnosticDetailRequests=new Map();
async function populateDiagnosticDetail(node){
  const bucket=Number(node.dataset.detailBucket);
  const radio=Number(node.dataset.detailRadio);
  const seq=Number(node.dataset.detailSeq);
  if(!Number.isSafeInteger(bucket)||bucket<0||bucket>5||
     !Number.isSafeInteger(radio)||radio<0||radio>255||
     !Number.isSafeInteger(seq)||seq<1)return;
  const key=bucket+':'+radio+':'+seq;
  if(!diagnosticDetailRequests.has(key)){
    if(diagnosticDetailRequests.size>50)diagnosticDetailRequests.clear();
    diagnosticDetailRequests.set(key,
      fetch('/api/logs/detail?bucket='+bucket+'&radio='+radio+'&seq='+seq,
            {cache:'no-store'})
        .then(async response=>{
          if(!response.ok)throw new Error('HTTP '+response.status);
          return response.text();
        }).catch(error=>'Additional detail unavailable: '+error.message));
  }
  const text=await diagnosticDetailRequests.get(key);
  if(node.isConnected)node.textContent=text;
}
function renderLogs(events){
  const tbody=$('log-rows');
  const scroller=tbody.closest('.table-wrap');
  const savedScroll=scroller?.scrollTop||0;
  const focusedKey=document.activeElement?.dataset?.logToggle;
  const displayed=events.filter(eventIsVisible).slice().reverse();
  const visibleKeys=new Set(displayed.map(logRowKey));
  for(const key of expandedLogKeys)if(!visibleKeys.has(key))expandedLogKeys.delete(key);
  tbody.replaceChildren();
  $('log-feedback').textContent=displayed.length+
    ' retained events on this page · select Older to read the full buffer · click an event to expand';
  renderLogCaptureDiagnostics();
  if(!displayed.length){
    const tr=document.createElement('tr'),td=document.createElement('td');td.colSpan=5;
    td.textContent='No retained events match these filters.';
    tr.append(td);tbody.append(tr);return;
  }
  for(const e of displayed){
    const key=logRowKey(e);
    const open=expandedLogKeys.has(key);
    const detailId='log-detail-'+key.replace(/[^a-zA-Z0-9_-]/g,'_');
    const tr=document.createElement('tr');tr.className='log-main-row';
    if(open)tr.classList.add('is-expanded');
    tr.dataset.logKey=key;
    if(e.severity===2)tr.classList.add('is-error');
    else if(e.severity===1)tr.classList.add('is-warning');
    const values=[localTimestamp(e.timestamp_utc_ms)||'Time not synchronized',e.stream||'—',
      radioNames[e.radio]||(e.stream==='web'?'Web UI / API':'System'),
      logEventTitle(e),logDetails(e)];
    for(let i=0;i<values.length;i++){
      const td=document.createElement('td');
      if(i===3){
        const button=document.createElement('button');
        button.type='button';button.className='log-expand-button';
        button.dataset.logToggle=key;
        button.setAttribute('aria-expanded',String(open));
        button.setAttribute('aria-controls',detailId);
        button.setAttribute('aria-label',(open?'Collapse':'Expand')+' details: '+values[3]);
        const arrow=document.createElement('span');arrow.className='log-expand-chevron';
        arrow.setAttribute('aria-hidden','true');arrow.textContent=open?'▾':'▸';
        const title=document.createElement('span');title.textContent=values[3];
        button.append(arrow,title);td.append(button);
      }else if(i===0){
        td.textContent=values[i];
        const elapsed=document.createElement('small');
        elapsed.className='log-time-uptime';
        elapsed.textContent='Uptime '+uptimeMs(e.uptime_ms);
        td.append(elapsed);
      }else td.textContent=values[i];
      if(i===4)td.className='detail';
      tr.append(td);
    }
    const detailRow=document.createElement('tr');
    detailRow.className='log-expanded-row';detailRow.id=detailId;
    detailRow.hidden=!open;detailRow.dataset.logDetail=key;
    const cell=document.createElement('td');cell.colSpan=5;
    const panel=document.createElement('div');panel.className='log-expanded-panel';
    const heading=document.createElement('strong');
    heading.textContent='Event details · '+String(e.kind||'Unknown');
    const grid=document.createElement('dl');grid.className='log-metadata-grid';
    for(const [label,value] of logMetadataFields(e)){
      const dt=document.createElement('dt');dt.textContent=label;
      const dd=document.createElement('dd');dd.textContent=String(value);
      grid.append(dt,dd);
    }
    panel.append(heading,grid);
    let raw=null, diagnostic=null;
    const rawSync=e.code===55, rawPre=e.code===46||(e.radio<2&&!!(Number(e.flags)&128));
    const rawSequence=rawSync||rawPre?e.sequence:e.correlation_id;
    if(((e.code>=1&&e.code<=8)||rawPre||rawSync)&&
       Number.isInteger(e.radio)&&e.radio>=0&&e.radio<3&&
       Number.isInteger(rawSequence)&&rawSequence>0){
      raw=document.createElement('pre');
      raw.className='log-rf-raw';
      raw.dataset.rawRadio=String(e.radio);
      raw.dataset.rawSeq=String(rawSequence);
      raw.dataset.rawPre=rawPre?'1':'0';
      raw.dataset.rawSync=rawSync?'1':'0';
      raw.textContent='Loading bounded raw RF capture…';
      panel.append(raw);
      const exportButton=document.createElement('button');
      exportButton.type='button';
      exportButton.className='secondary';
      exportButton.dataset.exportRfSeq=raw.dataset.rawSeq;
      exportButton.dataset.exportRfRadio=raw.dataset.rawRadio;
      exportButton.dataset.exportRfPre=raw.dataset.rawPre;
      exportButton.dataset.exportRfSync=raw.dataset.rawSync;
      exportButton.textContent='Export RF capture JSON';
      exportButton.title='Download exact pulses, FIFO bytes or clocked bits for offline protocol analysis';
      panel.append(exportButton);
    }else{
      const bucket=e.stream==='system'?4:e.stream==='web'?5:
        (Number.isInteger(e.radio)&&e.radio>=0&&e.radio<3?e.radio:-1);
      // A periodic outcome summary has no per-event diagnostic payload.
      // Do not show a misleading failed detail request on this row.
      if(e.code!==35 && bucket>=0 && Number.isSafeInteger(e.sequence)&&e.sequence>0){
        diagnostic=document.createElement('pre');
        diagnostic.className='log-rf-raw';
        diagnostic.dataset.detailBucket=String(bucket);
        diagnostic.dataset.detailRadio=String(bucket>=4?255:e.radio);
        diagnostic.dataset.detailSeq=String(e.sequence);
        diagnostic.textContent='Loading additional diagnostic details…';
        panel.append(diagnostic);
      }
    }
    cell.append(panel);detailRow.append(cell);
    tbody.append(tr,detailRow);
    if(open&&raw)void populateRawCapture(raw);
    if(open&&diagnostic)void populateDiagnosticDetail(diagnostic);
  }
  if(focusedKey){
    const button=[...tbody.querySelectorAll('button[data-log-toggle]')]
      .find(b=>b.dataset.logToggle===focusedKey);
    if(button)button.focus({preventScroll:true});
  }
  if(scroller)scroller.scrollTop=savedScroll;
}
$('log-rows').addEventListener('click',event=>{
  const row=event.target.closest('tr[data-log-key]');
  if(!row)return;
  const button=row.querySelector('button[data-log-toggle]');
  const detail=row.nextElementSibling;
  if(!button||!detail||detail.dataset.logDetail!==row.dataset.logKey)return;
  const nowOpen=detail.hidden;
  detail.hidden=!nowOpen;
  button.setAttribute('aria-expanded',String(nowOpen));
  button.setAttribute('aria-label',(nowOpen?'Collapse':'Expand')+
    ' details: '+button.querySelector('span:last-child').textContent);
  button.querySelector('.log-expand-chevron').textContent=nowOpen?'▾':'▸';
  row.classList.toggle('is-expanded',nowOpen);
  if(nowOpen){
    expandedLogKeys.add(row.dataset.logKey);
    pauseLogViewing();
    const raw=detail.querySelector('[data-raw-seq]');
    if(raw)void populateRawCapture(raw);
    const diagnostic=detail.querySelector('[data-detail-seq]');
    if(diagnostic)void populateDiagnosticDetail(diagnostic);
  }else expandedLogKeys.delete(row.dataset.logKey);
  auditUi(nowOpen?'log_expand':'log_collapse');
});

// Export is an explicit browser-only action inside the existing Logs panel.
// RF IDs and rolling counters stay out of the regular metadata CSV and UI audit.
$('log-rows').addEventListener('click',async event=>{
  const button=event.target.closest('button[data-export-rf-seq]');
  if(!button || button.disabled)return;
  const radio=Number(button.dataset.exportRfRadio);
  const seq=Number(button.dataset.exportRfSeq);
  const pre=button.dataset.exportRfPre==='1',sync=button.dataset.exportRfSync==='1';
  if(!Number.isSafeInteger(seq)||seq<1||!Number.isInteger(radio)||
     radio<0||radio>2)return;
  button.disabled=true;button.textContent='Preparing RF JSON…';
  try{
    const raw=await api('/api/radio/capture?radio='+radio+'&seq='+seq+
      (sync?'&sync=1':pre?'&pre=1':''));
    if(!raw.available)throw new Error('Capture overwritten or unavailable');
    const evidence={schema:'rflink-rf-capture-v1',type:sync?'sync868_preamble_window':pre?'pre_filter_rmt':'decoder_input',
      firmware:lastStatus?.firmware??'unknown',radio,radio_label:radioNames[radio],
      exported_at_utc:new Date().toISOString(),capture:raw};
    const blob=new Blob([JSON.stringify(evidence,null,2)+'\n'],{type:'application/json'});
    const url=URL.createObjectURL(blob),link=document.createElement('a');
    link.href=url;link.download='RFLink_RF_'+radio+'_'+seq+(sync?'_sync':pre?'_pre':'')+'.json';
    document.body.append(link);link.click();link.remove();
    setTimeout(()=>URL.revokeObjectURL(url),1500);
    button.textContent='Export RF capture JSON';
  }catch(error){button.textContent='Export failed: '+error.message;}
  finally{button.disabled=false;}
});
async function refreshLogBufferSummary(){
  try{
    const r=await api('/api/logs/config');
    const display=$('log-buffer-summary'),totals=$('log-buffer-totals');
    if(!r.ready){
      display.textContent='Log storage is not ready';
      totals.textContent='Not initialized';
      return;
    }
    const names=['433.42 MHz','433.92 MHz','868.30 MHz','Noise','System','Web'];
    const limits=[...(r.signal||[]),r.noise,512,512];
    const fragment=document.createDocumentFragment();
    let usedTotal=0,overwrittenTotal=0;
    for(let i=0;i<names.length;i++){
      const used=Number(r.used?.[i])||0,overwritten=Number(r.overwritten?.[i])||0;
      usedTotal+=used;overwrittenTotal+=overwritten;
      const tile=document.createElement('div');tile.className='log-buffer-item';
      const name=document.createElement('strong');name.textContent=names[i];
      const capacity=document.createElement('span');
      const detailUsed=Number(r.details?.used?.[i])||0;
      const detailCap=Number(r.details?.capacity?.[i])||0;
      capacity.textContent=fmt(used)+' / '+fmt(limits[i])+
        (r.details?.ready?' · details '+(detailUsed/1024).toFixed(0)+
         ' / '+(detailCap/1024).toFixed(0)+' KiB':'');
      const dropped=document.createElement('small');
      const detailEvicted=Number(r.details?.evicted?.[i])||0;
      dropped.textContent=(overwritten?fmt(overwritten)+' overwritten':'No overwritten entries')+
        (r.details?.ready?' · '+fmt(detailEvicted)+' detail FIFO evictions':'');
      if(overwritten)dropped.classList.add('has-overwritten');
      tile.append(name,capacity,dropped);
      // Present one tile per radio; separate internal retention remains.
      if(i<3){
        const sync=lastStatus?.rx868_sync_mode===true;
        const raw=i<2?r.raw433_capture:r.unknown868_fifo;
        if(raw&&Number.isFinite(raw.limit)&&!(i===2&&sync&&!Array.isArray(lastStatus?.rx_raw_candidates))){
          const n=Number(i<2?raw.used?.[i]:raw.used)||0;
          const lost=Number(i<2?raw.overwritten?.[i]:raw.overwritten)||0;
          usedTotal+=n;overwrittenTotal+=lost;
          const sub=document.createElement('span');
          sub.textContent=(i<2||sync?'RAW captures: ':'Unknown FIFO: ')+fmt(n)+' / '+fmt(raw.limit);
          if(i===2&&r.details?.ready)sub.textContent+=' · details '+(Number(r.details?.used?.[6]||0)/1024).toFixed(0)+' / '+(Number(r.details?.capacity?.[6]||0)/1024).toFixed(0)+' KiB';
          const loss=document.createElement('small');
          loss.textContent=fmt(lost)+' RAW records overwritten'+(i===2&&r.details?.ready?' · '+fmt(r.details?.evicted?.[6])+' detail evictions':'');
          if(lost)loss.classList.add('has-overwritten');
          tile.append(sub,loss);
        }else if(i===2&&sync){
          const sub=document.createElement('small');sub.textContent='Automatic RAW capture unavailable on this firmware';
          tile.append(sub);
        }
      }
      fragment.append(tile);
    }
    display.replaceChildren(fragment);
    totals.textContent=fmt(usedTotal)+' retained · '+fmt(overwrittenTotal)+' overwritten';
  }catch(error){$('log-buffer-summary').textContent='Buffer statistics unavailable: '+error.message;}
}
function syncLogFilterControls(){
  // System and Web never use the radio/noise filters; keep their previous
  // values so returning to Radio does not lose the user's selection.
  $('log-filter-controls').hidden=logSource==='system'||logSource==='web';
}
if(typeof window.matchMedia==='function' && window.matchMedia('(max-width:750px)').matches)
  $('log-buffer-details').open=false;
syncLogFilterControls();
async function refreshLogs(jumpToTop=false){
  if(logsBusy)return;
  logsBusy=true;
  // A reader freezes the current snapshot, like manual history paging.
  // Never clear it while a row is expanded or the live view is paused.
  if(logPageCursors.length===1&&!logLivePaused)logSnapshot=0;
  const pausedWhenRequested=logLivePaused;
  const query=selectedLogQuery(true);
  // Export uses every ring irrespective of the visible filter/query.
  $('log-export').href='/api/logs.csv';
  try{
    const r=await api('/api/logs'+(query.size?'?'+query.toString():''));
    // An already-running live request may return after a user expands a row.
    // Discard it rather than replacing the row they are reading.
    if(logLivePaused&&!pausedWhenRequested&&logPageCursors.length===1)return;
    logSnapshot=Number.isSafeInteger(r.snapshot)?r.snapshot:logSnapshot;
    logHasOlder=r.has_more===true;
    renderLogs(Array.isArray(r.events)?r.events:[]);
    if(jumpToTop){
      const scroller=$('log-rows').closest('.table-wrap');
      if(scroller)scroller.scrollTop=0;
    }
    const page=logPageCursors.length;
    $('log-page-number').textContent='Page '+page+
      (logLivePaused?' · paused':' · up to 64 entries');
    if(logLivePaused)$('log-feedback').textContent=
      'Viewing paused — new events are still recorded. Select Resume live to catch up.';
    $('log-older').disabled=!logHasOlder||!r.cursor;
    $('log-newer').disabled=page===1;
    $('log-latest').disabled=page===1&&!logLivePaused;
    $('log-latest').textContent=logLivePaused?'Resume live':'Latest events';
    $('log-older').dataset.cursor=String(r.cursor||'');
    if(page===1)refreshLogBufferSummary();
  }catch(error){$('log-feedback').textContent='Log feed unavailable: '+error.message;}
  finally{logsBusy=false;}
}
for(const button of document.querySelectorAll('[data-log-source]'))button.addEventListener('click',()=>{
  logSource=button.dataset.logSource;
  resetLogPages();
  syncLogFilterControls();
  // Preserve numeric audit source IDs from v0.7 (2 was the removed Noise tab).
  auditUi('log_source',['all','radio','noise','system','web'].indexOf(logSource));
  for(const tab of document.querySelectorAll('[data-log-source]')){
    const active=tab===button;tab.classList.toggle('selected',active);
    tab.setAttribute('aria-pressed',String(active));
  }
  refreshLogs();
});
$('log-radio').addEventListener('change',()=>{
  if($('log-radio').value==='2')$('sync868-panel').open=true;
  resetLogPages();
  auditUi('log_radio',Number($('log-radio').value)+1||0);
  renderLogCaptureDiagnostics();refreshLogs();
});
$('log-noise').addEventListener('change',()=>{
  resetLogPages();
  auditUi('log_noise',$('log-noise').checked?1:0);
  renderLogCaptureDiagnostics();refreshLogs();
});
// Experimental 868 synchronous capture. The existing firmware API remains the
// only owner of the bench store: the browser never changes RX profiles or TX.
// Never use routine Radio/System/Web logs to store raw bit samples or keys.
const sync868Path='/api/diagnostics/868-sync';
let sync868Busy=false,sync868Status=null,sync868ReplayRunning=false;
function sync868TrustedLan(){
  const host=window.location.hostname.toLowerCase();
  if(host==='localhost'||host==='127.0.0.1'||host.endsWith('.local')||
     /^[a-z0-9-]+$/.test(host))return true; // Single-label LAN hostname.
  const p=host.split('.').map(Number);
  if(p.length!==4||p.some(n=>!Number.isInteger(n)||n<0||n>255))return false;
  return p[0]===10||(p[0]===192&&p[1]===168)||
    (p[0]===172&&p[1]>=16&&p[1]<=31);
}
function sync868Access(){
  if(!sync868TrustedLan())throw new Error('Use the ESP32 local LAN address, not remote Ingress or a public proxy');
  const key=$('sync868-key').value;
  if(key.length<12||key.length>64)throw new Error('Enter a 12–64 character management key');
  return {'X-RFLink-Update-Key':key};
}
function sync868Buttons(){
  const ready=!sync868Busy&&sync868Status&&sync868TrustedLan()&&
    $('sync868-key').value.length>=12;
  $('sync868-status').disabled=sync868Busy;
  $('sync868-arm').disabled=!ready||!sync868Status.receiver_listening||
    sync868Status.recording;
  $('sync868-freeze').disabled=!ready||!sync868Status.recording;
  $('sync868-analyze').disabled=!ready||sync868Status.recording||
    !sync868Status.recorded_bits||sync868ReplayRunning;
  $('sync868-inverted').disabled=!ready||sync868ReplayRunning;
  $('sync868-export').disabled=!ready||sync868Status.recording||
    !sync868Status.recorded_bits||sync868ReplayRunning;
}
function showSync868Status(r){
  if(r.schema!=='rflink-sync-bits-v1'||r.mode!=='BENCH_ONLY')
    throw new Error('Unexpected capture API schema');
  for(const field of ['capacity_blocks','used_blocks','recorded_bits',
    'capture_discontinuities','ring_dropped_total','clock_missing_reported_total',
    'capture_blocks_dropped_total']){
    if(!Number.isSafeInteger(r[field])||r[field]<0)
      throw new Error('Invalid 868 capture statistics');
  }
  sync868Status=r;
  $('sync868-stats').hidden=false;
  $('sync868-listening').textContent=r.receiver_listening?'Listening':'Not listening';
  $('sync868-state').textContent=r.recording?'Recording':
    r.full?'Full · automatically frozen':r.recorded_bits?'Frozen':'Idle';
  $('sync868-blocks').textContent=fmt(r.used_blocks)+' / '+fmt(r.capacity_blocks);
  $('sync868-bits').textContent=fmt(r.recorded_bits);
  $('sync868-gaps').textContent=fmt(r.capture_discontinuities)+
    ' known in capture';
  $('sync868-drops').textContent=fmt(r.ring_dropped_total)+' ring · '+
    fmt(r.clock_missing_reported_total)+' clock · '+
    fmt(r.capture_blocks_dropped_total)+' blocks (boot totals)';
  sync868Buttons();
}
async function refreshSync868(){
  if(sync868Busy)return;
  sync868Busy=true;sync868Buttons();
  try{
    const headers=sync868Access();
    const response=await api(sync868Path,{headers});
    showSync868Status(response);
    $('sync868-feedback').textContent=response.recording?
      'Recording · the oldest bits are retained until freeze or buffer full.':
      response.full?'Capture is full. Export it, or arm again to replace it.':
      'Capture status loaded. Arm only when ready to operate a known 868 MHz device.';
  }catch(error){
    sync868Status=null;$('sync868-stats').hidden=true;
    $('sync868-feedback').textContent=error.message;
  }finally{sync868Busy=false;sync868Buttons();}
}
async function sync868Command(action){
  if(sync868Busy)return;
  try{sync868Access();}catch(error){$('sync868-feedback').textContent=error.message;return;}
  if(action==='arm'&&!window.confirm(
    'Arm a new 868 MHz RAW capture? This clears the previous capture from PSRAM.'))return;
  sync868Busy=true;sync868Buttons();
  try{
    const headers={...sync868Access(),'Content-Type':'text/plain'};
    await api(sync868Path,{method:'POST',headers,body:action});
    if(action==='arm'){
      $('sync868-analysis').hidden=true;
      $('sync868-analysis').textContent='';
      $('sync868-decode-report').hidden=true;
      $('sync868-match-panel').hidden=true;
    }
    $('sync868-feedback').textContent=action==='arm'?
      'Recording started. Operate the 868 MHz device now, then select Freeze.':
      'Recording frozen. You can export and inspect the captured CSV.';
  }catch(error){$('sync868-feedback').textContent=error.message;}
  finally{sync868Busy=false;sync868Buttons();}
  // Fetch the exact state again; successful POST alone is not a UI snapshot.
  refreshSync868();
}
// Native C++ Itho/RAMSES replay executes on the ESP32's low-priority worker.
// It returns only bounded, explicitly graded diagnostic metadata, never RF
// addresses, rolling codes, original bytes or an automatic device event.
const sync868ReplayPath='/api/diagnostics/868-replay';
function clearSync868Replay(){
  $('sync868-decode-report').hidden=true;
  $('sync868-match-panel').hidden=true;
  $('sync868-candidates').replaceChildren();
}
function renderSync868Replay(report){
  const status=$('sync868-decode-report'),panel=$('sync868-match-panel');
  const records=$('sync868-candidates');
  records.replaceChildren();
  const hits=Array.isArray(report.matches)?report.matches.slice(0,40):[];
  const ih=Number(report.candidate_itho_structure_only)||0;
  const ram=Number(report.checksum_valid_ramses_ii)||0;
  const embedded=Number(report.ramses_ii_embedded_in_itho)||0;
  const outside=Number(report.ramses_ii_outside_itho)||0;
  status.textContent='Native 868 replay · '+fmt(report.recorded_bits)+
    ' bits · '+fmt(report.segments)+' continuous segments · '+
    fmt(ih)+' Itho structure-only candidates · '+
    fmt(ram)+' checksum-valid RAMSES-II matches ('+
    fmt(embedded)+' embedded in Itho, '+fmt(outside)+
    ' outside recognized Itho). '+
    (report.hits_truncated?'Candidate list capped at 40; overlap totals may be partial. ':
      'Candidate list complete. ')+
    'No RF hardware validation; neither count proves an actual device action.';
  status.hidden=false;
  $('sync868-match-count').textContent=String(hits.length)+
    (report.hits_truncated?'+':'');
  panel.hidden=hits.length===0;
  for(const h of hits){
    const item=document.createElement('div');
    item.className='sync868-candidate';
    const name=h.protocol==='itho'?'Itho structural candidate':
      'RAMSES-II checksum-valid telegram';
    const prefix=h.polarity==='inverted'?'inverted':'normal';
    const marker=h.embedded_in_itho_candidate?' · embedded within Itho candidate':
      h.overlapping?' · overlaps other protocol':'';
    item.textContent=name+' · '+String(h.summary||'type=unknown')+
      ' · segment '+fmt(h.segment)+' / epoch '+fmt(h.epoch)+
      ' · bit '+fmt(h.bit_offset)+' · '+fmt(h.span_bits)+
      ' bits · '+prefix+marker;
    records.appendChild(item);
  }
}
async function pollSync868Replay(){
  if(!$('sync868-panel').open||!$('sync868-key').value)return;
  try{
    const headers=sync868Access();
    const state=await api(sync868ReplayPath,{headers});
    if(state.schema!=='rflink-sync-replay-device-v1')
      throw new Error('Unexpected native replay report');
    sync868ReplayRunning=state.state==='running';
    if(sync868ReplayRunning)
      $('sync868-feedback').textContent='Native replay · '+fmt(state.progress_blocks)+
        ' / '+fmt(state.total_blocks)+' RAW blocks analyzed. Radio RX stays active.';
    if(state.state==='failed'){
      clearSync868Replay();
      $('sync868-feedback').textContent='Native decoder failed to process the frozen capture.';
    }
    if(state.state==='complete' && state.report){
      // An old report must NEVER be shown as evidence from a newly armed run.
      if(sync868Status && state.source_generation!==sync868Status.generation){
        clearSync868Replay();
      }else{
        renderSync868Replay(state.report);
        $('sync868-feedback').textContent='Native decoder finished. Raw bits remain in the private buffer.';
      }
    }
    sync868Buttons();
  }catch(error){
    sync868ReplayRunning=false;
    $('sync868-feedback').textContent='Native replay status unavailable: '+error.message;
    sync868Buttons();
  }
}
async function startSync868Replay(){
  if(sync868Busy||sync868ReplayRunning)return;
  sync868Busy=true;sync868Buttons();
  try{
    const headers={...sync868Access(),'Content-Type':'text/plain'};
    const inverted=$('sync868-inverted').checked;
    await api(sync868ReplayPath,{method:'POST',headers,
      body:inverted?'analyze-inverted':'analyze'});
    clearSync868Replay();
    sync868ReplayRunning=true;
    $('sync868-feedback').textContent='Native decoder started on frozen RAW snapshot.';
  }catch(error){
    $('sync868-feedback').textContent='Native replay not started: '+error.message;
  }finally{sync868Busy=false;sync868Buttons();}
  if(sync868ReplayRunning)pollSync868Replay();
}
// Pure offline CSV inspector. Bit payload never becomes a log entry, network
// request or HTML. Calculate effective *sample throughput*, not crystal ppm.
// Each intra-block interval is counted once; 2,048-bit blocks are NOT frames.
function inspectSync868Csv(csv){
  const lines=csv.trim().split(/\r?\n/),metadata={};
  let row=0;
  while(row<lines.length&&lines[row].startsWith('#')){
    const pair=lines[row++].slice(1).split(',');
    if(pair.length!==2||!pair[0]||Object.hasOwn(metadata,pair[0]))
      throw new Error('Invalid capture metadata');
    metadata[pair[0]]=pair[1];
  }
  if(metadata.schema!=='rflink-sync-bits-v1'||metadata.mode!=='BENCH_ONLY'||
     metadata.radio!=='868.30 MHz')throw new Error('Unexpected 868 CSV schema');
  const header='index,epoch,bit_count,first_us,last_us,discontinuity_before,window_end,hex_msb';
  if(lines[row++]!==header)throw new Error('Unexpected CSV columns');
  const integer=(s,name)=>{
    if(!/^\d+$/.test(s))throw new Error('Invalid '+name);
    const n=Number(s);
    if(!Number.isSafeInteger(n))throw new Error('Overflow in '+name);
    return n;
  };
  const cap=integer(metadata.capacity,'capacity'),count=integer(metadata.blocks,'blocks');
  if(cap!==256||count>cap||lines.length-row!==count)
    throw new Error('Unexpected number of bit blocks');
  let totalBits=0,ones=0,discontinuities=0,segments=0,epochs=0;
  let totalEdgeIntervals=0,totalMicroseconds=0,previous=null;
  for(let i=0;i<count;i++){
    const part=lines[row+i].split(',');
    if(part.length!==8)throw new Error('Malformed bit block row');
    const [index,epoch,bits,first,last,gap,end]=part.slice(0,7)
      .map((s,j)=>integer(s,['index','epoch','bit count','first timestamp',
                            'last timestamp','gap','window end'][j]));
    const hex=part[7];
    if(index!==i||bits<1||bits>2048||last<first||gap>1||end>1||
       !/^[\dA-Fa-f]+$/.test(hex)||hex.length!==2*Math.ceil(bits/8))
      throw new Error('Invalid block order, timing or encoded bits');
    if(bits%8){
      const tail=parseInt(hex.slice(-2),16);
      if((tail&((1<<(8-bits%8))-1))!==0)
        throw new Error('Nonzero padding bits');
    }
    for(let b=0;b<Math.ceil(bits/8);b++){
      let value=parseInt(hex.slice(b*2,b*2+2),16);
      if(b===Math.floor(bits/8)&&bits%8)value&=0xff<<(8-bits%8);
      while(value){ones++;value&=value-1;}
    }
    totalBits+=bits;discontinuities+=gap;
    totalEdgeIntervals+=bits-1;totalMicroseconds+=last-first;
    if(!previous||previous.epoch!==epoch||previous.end||gap)segments++;
    if(!previous||previous.epoch!==epoch)epochs++;
    previous={epoch,end};
  }
  if(totalBits!==integer(metadata.recorded_bits,'recorded bit total'))
    throw new Error('Recorded bit count does not match CSV');
  if(![0,1].includes(integer(metadata.full,'full flag')))
    throw new Error('Invalid full flag');
  const rate=totalMicroseconds>0?totalEdgeIntervals*1000000/totalMicroseconds:null;
  return {blocks:count,bits:totalBits,segments,epochs,discontinuities,
    onesPercent:totalBits?ones*100/totalBits:null,rate};
}
async function exportSync868(){
  if(sync868Busy)return;
  sync868Busy=true;sync868Buttons();
  const feedback=$('sync868-feedback');
  feedback.textContent='Downloading private RAW capture from the ESP32…';
  try{
    const headers=sync868Access();
    const response=await fetch(sync868Path+'.csv',{headers,cache:'no-store'});
    if(!response.ok)throw new Error('RFLink HTTP '+response.status);
    if(!String(response.headers.get('Content-Type')||'').toLowerCase().includes('text/csv'))
      throw new Error('RFLink did not return a CSV');
    const limit=512*1024; // 256 * 2,048 bits plus bounded CSV metadata.
    let size=0,blob;
    if(response.body&&typeof response.body.getReader==='function'){
      const reader=response.body.getReader(),chunks=[];
      while(true){
        const {done,value}=await reader.read();
        if(done)break;
        size+=value.byteLength;
        if(size>limit){await reader.cancel();throw new Error('RAW capture exceeds safe size');}
        chunks.push(value);
      }
      blob=new Blob(chunks,{type:'text/csv;charset=utf-8'});
    }else{
      blob=await response.blob();size=blob.size;
      if(size>limit)throw new Error('RAW capture exceeds safe size');
    }
    const report=inspectSync868Csv(await blob.text());
    const view=$('sync868-analysis');
    view.textContent='CSV validated · '+fmt(report.bits)+' bits in '+
      fmt(report.blocks)+' blocks · '+fmt(report.segments)+' contiguous segments · '+
      fmt(report.epochs)+' receiver epochs · '+fmt(report.discontinuities)+
      ' reported discontinuities · 1-bit balance '+
      (report.onesPercent===null?'—':report.onesPercent.toFixed(2)+'%')+
      ' · effective intra-block sampling rate '+
      (report.rate===null?'unknown':fmt(Math.round(report.rate))+' bits/s')+
      '. Not a protocol decode or proof of complete physical clock capture.';
    view.hidden=false;
    const url=URL.createObjectURL(blob),link=document.createElement('a');
    link.href=url;
    link.download='RFLink_868_SyncBits_Bench_g'+
      String(sync868Status?.generation??'capture')+'.csv';
    document.body.appendChild(link);link.click();link.remove();
    setTimeout(()=>URL.revokeObjectURL(url),30000);
    feedback.textContent='Private capture exported and inspected in this browser ('+
      bytes(size)+'). The CSV was not added to logs.';
  }catch(error){
    feedback.textContent='RAW export failed: '+error.message;
  }finally{sync868Busy=false;sync868Buttons();}
}
$('sync868-key').addEventListener('input',()=>{
  sync868Status=null;$('sync868-stats').hidden=true;
  $('sync868-analysis').hidden=true;
  sync868ReplayRunning=false;clearSync868Replay();
  $('sync868-feedback').textContent='Key changed. Refresh status to authorize the bench.';
  sync868Buttons();
});
$('sync868-panel').addEventListener('toggle',()=>{
  if($('sync868-panel').open&&$('sync868-key').value){
    refreshSync868();pollSync868Replay();
  }
});
$('sync868-status').addEventListener('click',refreshSync868);
$('sync868-arm').addEventListener('click',()=>sync868Command('arm'));
$('sync868-freeze').addEventListener('click',()=>sync868Command('freeze'));
$('sync868-export').addEventListener('click',exportSync868);
$('sync868-analyze').addEventListener('click',startSync868Replay);
window.addEventListener('pagehide',()=>{$('sync868-key').value='';sync868Status=null;});
// The server streams CSV in unknown-length HTTP chunks. Use exact Content-
// Length if exposed, otherwise count completed event rows against the export
// snapshot estimate. Never pretend that an approximate percentage is exact.
let csvExportRunning=false;
let csvExportHideTimer=null;
async function exportFullCsv(event){
  event.preventDefault();
  if(csvExportRunning)return;
  csvExportRunning=true;
  if(csvExportHideTimer!==null){clearTimeout(csvExportHideTimer);csvExportHideTimer=null;}
  const link=$('log-export'),box=$('log-export-progress');
  const meter=$('log-export-meter'),label=$('log-export-percent');
  const status=$('log-export-state'),feedback=$('log-export-feedback');
  link.classList.add('busy');link.setAttribute('aria-disabled','true');
  box.hidden=false;meter.removeAttribute('value');
  label.textContent='—';status.textContent='CSV ophalen…';
  feedback.textContent='Voorbereiden · de rest van RFLink blijft beschikbaar.';
  auditUi('log_export');
  try{
    // Ordinary full CSV includes all retained RAW candidate details by default.
    // A separate, manually frozen bench recording is an optional addition.
    let exportUrl=link.href,exportHeaders={},embeddedRaw=false;
    if(sync868TrustedLan()&&$('sync868-key').value.length>=12){
      try{
        const headers=sync868Access();
        const captured=await api(sync868Path,{headers});
        showSync868Status(captured);
        if(!captured.recording&&captured.recorded_bits>0){
          const url=new URL(link.href,window.location.href);
          url.searchParams.set('sync868_raw','1');
          exportUrl=url.toString();
          exportHeaders=headers;
          embeddedRaw=true;
        }
      }catch(error){
        // A missing/incorrect bench key must not block ordinary diagnostics.
        console.warn('Optional frozen 868 recording not included');
      }
    }
    const response=await fetch(exportUrl,{cache:'no-store',headers:exportHeaders});
    if(!response.ok)throw new Error('HTTP '+response.status);
    if(!String(response.headers.get('Content-Type')||'').toLowerCase().includes('text/csv'))
      throw new Error('RFLink heeft geen CSV teruggestuurd');
    const expectedBytes=Number(response.headers.get('Content-Length'));
    const expectedRows=Number(response.headers.get('X-RFLink-Export-Estimated-Events'));
    const byteTotal=Number.isFinite(expectedBytes)&&expectedBytes>0?expectedBytes:0;
    const rowEstimate=Number.isSafeInteger(expectedRows)&&expectedRows>0?expectedRows:0;
    const limit=96*1024*1024; // Mirrors the Builder's existing stream ceiling.
    let count=0,completedRows=0,partial='',lastPaint=0;
    let blob;
    if(response.body&&typeof response.body.getReader==='function'){
      const reader=response.body.getReader(),chunks=[],decoder=new TextDecoder();
      while(true){
        const {done,value}=await reader.read();
        if(done)break;
        if(!value||!value.byteLength)continue;
        count+=value.byteLength;
        if(count>limit){await reader.cancel();throw new Error('CSV exceeds 96 MiB safety limit');}
        chunks.push(value);
        // Event CSV rows begin with "event"; context/header rows are excluded.
        const lines=(partial+decoder.decode(value,{stream:true})).split('\n');
        partial=lines.pop();
        for(const line of lines)if(line.startsWith('"event",'))completedRows++;
        const now=Date.now();
        if(now-lastPaint>200){
          lastPaint=now;
          const fraction=byteTotal?count/byteTotal:rowEstimate?completedRows/rowEstimate:null;
          if(fraction!==null){
            const percent=Math.min(99,Math.max(0,Math.floor(fraction*100)));
            meter.value=percent;
            label.textContent=(byteTotal?'':'≈')+percent+'%';
          }
          feedback.textContent=bytes(count)+' ontvangen · '+fmt(completedRows)+
            (rowEstimate?' / ca. '+fmt(rowEstimate):'')+' logregels · RFLink blijft bereikbaar.';
        }
      }
      blob=new Blob(chunks,{type:'text/csv;charset=utf-8'});
    }else{
      feedback.textContent='De browser verzamelt de CSV; voortgang is niet beschikbaar.';
      blob=await response.blob();count=blob.size;
      if(count>limit)throw new Error('CSV exceeds 96 MiB safety limit');
    }
    // Only save a fully completed response. Browser download starts after the
    // stream has been received; a truncated HTTP stream throws above.
    const url=URL.createObjectURL(blob),download=document.createElement('a');
    download.href=url;
    download.download=link.getAttribute('download')||'RFLink_Diagnostics_Full.csv';
    download.style.display='none';
    document.body.appendChild(download);download.click();download.remove();
    setTimeout(()=>URL.revokeObjectURL(url),30000);
    meter.value=100;label.textContent='100%';
    status.textContent='CSV ontvangen · download gestart';
    feedback.textContent=bytes(count)+' ontvangen'+
      (embeddedRaw?' · frozen 868 RAW included':'')+
      ' · retained RAW details (all radios)'+
      '. Je kunt RFLink normaal blijven gebruiken.';
    // Keep completed progress visible for five seconds, then dismiss it.
    csvExportHideTimer=setTimeout(()=>{box.hidden=true;csvExportHideTimer=null;},5000);
  }catch(error){
    meter.removeAttribute('value');label.textContent='Mislukt';
    status.textContent='CSV export mislukt';
    feedback.textContent=(error?.message||'Verbinding onderbroken')+
      ' · Probeer de export opnieuw.';
  }finally{
    csvExportRunning=false;
    link.classList.remove('busy');link.removeAttribute('aria-disabled');
  }
}
$('log-export').addEventListener('click',exportFullCsv);
$('log-older').addEventListener('click',()=>{
  const cursor=Number($('log-older').dataset.cursor);
  if(!logHasOlder||!Number.isSafeInteger(cursor)||cursor<1)return;
  logPageCursors.push(cursor);
  auditUi('log_older',logPageCursors.length);
  refreshLogs();
});
$('log-newer').addEventListener('click',()=>{
  if(logPageCursors.length===1)return;
  logPageCursors.pop();
  auditUi('log_newer',logPageCursors.length);
  if(logPageCursors.length===1&&!logLivePaused)logSnapshot=0;
  refreshLogs();
});
$('log-latest').addEventListener('click',()=>{
  resetLogPages();
  auditUi('log_latest');
  refreshLogs(true);
});
for(const button of document.querySelectorAll('[data-radio-log]')){
  button.addEventListener('click',()=>{
    logSource='radio';
    resetLogPages();
    syncLogFilterControls();
    auditUi('radio_inspect',Number(button.dataset.radioLog)+1);
    for(const tab of document.querySelectorAll('[data-log-source]')){
      const active=tab.dataset.logSource==='radio';
      tab.classList.toggle('selected',active);
      tab.setAttribute('aria-pressed',String(active));
    }
    $('log-radio').value=button.dataset.radioLog;
    if(button.dataset.radioLog==='2')$('sync868-panel').open=true;
    $('log-noise').checked=true;
    showPage('logs');
  });
}
function renderHistory(report){
  const ota=report.ota_health;
  $('diag-ota-state').textContent=ota?'Saved in NVS':'No saved OTA health';
  $('diag-ota-version').textContent=ota?.firmware||'No report';
  $('diag-ota-boot').textContent=ota?.boot?'#'+ota.boot:'—';
  const outcomes={valid:'Validated (ESP-IDF marked valid)',
    failed:'Boot health failed (rollback expected)',
    checking:'Validation started; final result not recorded',
    validation_error:'Could not mark firmware valid'};
  $('diag-ota-outcome').textContent=ota?(outcomes[ota.outcome]||ota.outcome):'Not recorded';
  $('diag-ota-receivers').textContent=ota?
    fmt(ota.active_receivers)+' active · '+fmt(ota.responsive_radios)+
      ' SPI responsive · worker '+(ota.worker_ok?'OK':'not ready'):'Not recorded';
  $('diag-reset').textContent=report.last_reset||'Unknown';
  markStatus($('diag-reset-badge'),'Saved on device',report.history_saved?'online':'warn');
  const dump=report.core_dump||{};
  $('diag-core').textContent=dump.integrity==='valid'?'Valid':
    dump.integrity==='invalid_or_unreadable'?'Unreadable':'Not available';
  $('diag-crash-pc').textContent=dump.summary_available?
    (dump.task||'Unknown task')+' · '+(dump.pc||'PC unknown'):'No usable crash PC';
  $('diag-compare').textContent=dump.build_comparison||'Unknown';
  const phases=new Map((report.boot_phases||[]).map(p=>[p.boot,p]));
  const list=$('diag-boots');list.replaceChildren();
  if(!Array.isArray(report.history)||!report.history.length){
    list.textContent='No persisted restarts available.';return;
  }
  for(const item of report.history.slice(0,12)){
    const row=document.createElement('div');row.className='boot-item';
    const reason=document.createElement('strong');reason.textContent='#'+item.boot+' · '+(item.reason||'Unknown');
    const stage=document.createElement('span');
    const phase=phases.get(item.boot);
    const checkpoint=phase?(String(phase.stage||'unknown').replaceAll('_',' ')+
      (phase.startup_complete?' · ready':' · last reached')):'Checkpoint unavailable';
    const bootTime=localTimestamp(item.boot_started_utc_ms);
    stage.textContent=(bootTime?'Started '+bootTime+' · ':'Date unknown · ')+checkpoint;
    row.append(reason,stage);list.append(row);
  }
}
async function refreshHistory(){
  if(historyBusy)return;historyBusy=true;
  try{renderHistory(await api('/api/diagnostics/crashes'));}
  catch(error){$('diag-boots').textContent='Boot history unavailable: '+error.message;}
  finally{historyBusy=false;}
}
$('diag-refresh').addEventListener('click',()=>{auditUi('diagnostics_refresh');refreshHistory();});
function disconnectConsole(){
  consoleConnected=false;consoleCursor=0;consoleBootId=null;
  $('console-connect').disabled=false;$('console-disconnect').disabled=true;
  markStatus($('console-state'),'Disconnected');
}
$('console-disconnect').addEventListener('click',()=>{auditUi('console_disconnect');disconnectConsole();});
$('console-clear').addEventListener('click',()=>{
  auditUi('console_clear');
  $('console-output').textContent='';
});
$('console-connect').addEventListener('click',()=>{
  auditUi('console_connect');
  // The captured console is read-only and already filtered before sharing.
  consoleConnected=true;consoleCursor=0;consoleBootId=null;
  $('console-connect').disabled=true;$('console-disconnect').disabled=false;
  markStatus($('console-state'),'Connecting','warn');pollConsole();
});
async function pollConsole(){
  if(!consoleConnected||consoleBusy||currentPage!=='diagnostics')return;
  consoleBusy=true;
  try{
    let r=await api('/api/diagnostics/console?since='+consoleCursor);
    if(consoleBootId!==null&&r.boot_id!==consoleBootId){
      $('console-output').textContent+='\n— ESP32 rebooted: new application console —\n';
      consoleCursor=0;
      r=await api('/api/diagnostics/console?since=0');
      refreshHistory();
    }
    consoleBootId=r.boot_id;
    if(r.truncated)$('console-output').textContent+='\n— Earlier console lines overwritten in RAM —\n';
    if(typeof r.text==='string'&&r.text.length){
      const el=$('console-output');
      el.textContent=(el.textContent+r.text).slice(-100000);
      el.scrollTop=el.scrollHeight;
    }
    if(Number.isSafeInteger(r.cursor))consoleCursor=r.cursor;
    markStatus($('console-state'),'Live','online');
  }catch(error){
    markStatus($('console-state'),'Unavailable','warn');
    const text='\n— Live console unavailable: '+error.message+' —\n';
    const out=$('console-output');
    if(!out.textContent.endsWith(text))out.textContent+=text;
    if(/403|404/.test(error.message))disconnectConsole();
  }finally{consoleBusy=false;}
}
async function refreshSettings(){
  try{
    const r=await api('/api/logs/config');
    if(!r.ready){$('log-budget').textContent='Log storage is not initialized yet.';return;}
    for(let i=0;i<3;i++)$('logs-settings-form').elements['signal_'+i].value=r.signal[i];
    $('logs-settings-form').elements.noise.value=r.noise;
    $('log-budget').textContent=Math.round(r.allocated_bytes/1024)+' KB allocated of '+
      Math.round(r.budget_bytes/1024)+' KB · '+
      (r.overwritten||[]).reduce((a,b)=>a+b,0)+' overwritten events';
  }catch(error){$('log-budget').textContent='Log settings unavailable: '+error.message;}
  try{
    const mqtt=await api('/api/mqtt/status');
    $('settings-mqtt').textContent=mqtt.configured?(mqtt.connected?'Connected':'Not connected'):'Not configured';
  }catch{$('settings-mqtt').textContent='Unavailable';}
  try{
    const led=await api('/api/led');
    $('led-enabled').checked=led.enabled===true;
    $('led-brightness').value=Number.isInteger(led.brightness)?led.brightness:20;
    $('led-mode').textContent=String(led.mode||'unknown').replaceAll('_',' ');
    $('led-driver').textContent=led.driver_ready?'Ready on GPIO'+led.gpio:
      'Unavailable (radio receivers have priority)';
  }catch(error){
    $('led-mode').textContent='Unavailable';
    $('led-driver').textContent='Status unavailable: '+error.message;
  }
}
$('led-settings-form').addEventListener('submit',async e=>{
  e.preventDefault();
  auditUi('led_submit');
  const status=$('led-save-status');
  const brightness=Number($('led-brightness').value);
  if(!Number.isSafeInteger(brightness)||brightness<1||brightness>100){
    status.textContent='Choose brightness between 1 and 100%.';return;
  }
  status.textContent='Saving LED settings…';
  try{
    const result=await api('/api/led',{method:'POST',headers:{
      'Content-Type':'application/json'
    },body:JSON.stringify({enabled:$('led-enabled').checked,brightness})});
    status.textContent=result.saved===true?
      'Saved to RFLink. The LED updates without reboot and survives firmware OTA.':
      'LED settings were not saved.';
    await refreshSettings();
  }catch(error){status.textContent='Could not save LED settings: '+error.message;}
});
// Local browser upload reuses the OTA API; the password is not stored in
// browser settings or placed in a query string. The ESP32 validates the image.
function renderOtaReadiness(s){
  const label=$('ota-safety');
  const safe=s?.ota_update_safe===true;
  if(!s)label.textContent='Device status unavailable. OTA is disabled.';
  else if(s.ota_busy)label.textContent='OTA already in progress. Do not restart the board.';
  else if(!safe)label.textContent='Browser OTA blocked: '+
    String(s.ota_layout_issue||'no safe inactive slot').replaceAll('_',' ')+
    '. Use a safe USB recovery method instead.';
  else label.textContent='Safe inactive OTA slot available ('+s.ota_slot_count+
    ' slots). The firmware board profile must match exactly.';
  label.classList.toggle('warn',!safe);
  $('ota-install').disabled=!safe||Boolean(s?.ota_busy)||otaUploading;
}
$('ota-form').addEventListener('submit',async event=>{
  event.preventDefault();
  if(otaUploading)return;
  const message=$('ota-feedback'),firmware=$('ota-file').files[0];
  const password=$('ota-key').value,progress=$('ota-progress');
  if(!lastStatus||lastStatus.ota_update_safe!==true||lastStatus.ota_busy){
    message.textContent='OTA is not safe or is already busy. Check the slot status.';return;
  }
  if(!firmware||!/\.bin$/i.test(firmware.name)||firmware.size<256||firmware.size>4*1024*1024){
    message.textContent='Select an ESP-IDF .bin image between 256 bytes and 4 MB.';return;
  }
  if(password.length<12||password.length>64){
    message.textContent='Enter the OTA administrator password (12–64 characters).';return;
  }
  try{
    const header=new Uint8Array(await firmware.slice(0,1).arrayBuffer());
    if(header[0]!==0xe9){
      message.textContent='Invalid ESP32 application image header. Upload cancelled.';return;
    }
  }catch{message.textContent='Cannot inspect the selected firmware file.';return;}
  if(!window.confirm('Install '+firmware.name+' on this RFLink test board? The board will restart after a successful upload.'))return;
  auditUi('ota_confirm');
  otaUploading=true;progress.value=0;renderOtaReadiness(lastStatus);
  message.textContent='Uploading firmware… keep the board powered.';
  const request=new XMLHttpRequest();
  request.open('POST','/api/ota');
  request.setRequestHeader('Content-Type','application/octet-stream');
  request.setRequestHeader('X-RFLink-Update-Key',password);
  request.upload.onprogress=e=>{
    if(e.lengthComputable)progress.value=Math.min(99,Math.round(e.loaded/e.total*100));
  };
  request.onload=()=>{
    auditUi('ota_result',request.status);
    if(request.status>=200&&request.status<300){
      progress.value=100;
      message.textContent='Firmware accepted; RFLink is restarting. Check the new version after reconnecting.';
      $('ota-key').value='';
      // Keep new writes disabled until the page is reloaded.
    }else{
      message.textContent='Upload rejected (HTTP '+request.status+'): '+
        (request.responseText||'Check the image, password and partition layout.');
      otaUploading=false;renderOtaReadiness(lastStatus);
    }
  };
  request.onerror=()=>{
    auditUi('ota_result',0);
    message.textContent='Connection lost during OTA. Result unknown; verify device status before retrying.';
    otaUploading=false;renderOtaReadiness(null);
  };
  request.onabort=()=>{
    auditUi('ota_result',0);
    message.textContent='Upload aborted. Verify the device before retrying.';
    otaUploading=false;renderOtaReadiness(null);
  };
  request.send(firmware);
});
$('logs-settings-form').addEventListener('submit',async e=>{
  e.preventDefault();
  auditUi('settings_submit');
  const form=e.currentTarget,status=$('settings-save-status');
  const data={};
  for(const field of ['signal_0','signal_1','signal_2','noise']){
    const input=form.elements[field],value=Number(input.value);
    if(!Number.isSafeInteger(value)||value<0||value>Number(input.max)){
      status.textContent='Enter valid integer limits for all buffers.';return;
    }
    data[field]=value;
  }
  status.textContent='Saving logging settings…';
  try{
    const saved=await api('/api/logs/config',{method:'POST',headers:{
      'Content-Type':'application/json'},body:JSON.stringify(data)});
    status.textContent=saved.saved===true?'Saved on RFLink. Settings survive reboot.':
      'Applied for this session, but not saved to flash. '+(saved.warning||'');
    await refreshSettings();
  }catch(error){status.textContent='Could not save: '+error.message;}
});
document.addEventListener('visibilitychange',()=>{
  if(document.visibilityState==='visible'){
    refreshStatus();if(currentPage==='logs'&&logPageCursors.length===1&&!logLivePaused)refreshLogs();
    if(currentPage==='diagnostics'){refreshHistory();pollConsole();}
  }
});
async function tick(){
  if(document.visibilityState==='hidden')return;
  await refreshStatus();
  if(currentPage==='status')refreshEvents();
  if(currentPage==='logs'&&logPageCursors.length===1&&!logLivePaused)refreshLogs();
  if(currentPage==='logs'&&$('sync868-panel').open&&$('sync868-key').value){
    refreshSync868();pollSync868Replay();
  }
  if(currentPage==='diagnostics'){refreshHistory();pollConsole();}
}
refreshStatus().then(refreshEvents);
auditUi('page_open');
setInterval(tick,5000);
