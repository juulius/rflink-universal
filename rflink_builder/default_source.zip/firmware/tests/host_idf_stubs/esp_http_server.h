#pragma once
#include <cstdint>
#include <cstddef>
#include "esp_err.h"
using httpd_handle_t=void*;
struct httpd_req_t{int content_len=0;};
struct httpd_config_t{unsigned stack_size=0;int max_uri_handlers=0;int recv_wait_timeout=0;};
#define HTTPD_DEFAULT_CONFIG() httpd_config_t{}
struct httpd_uri_t{const char* uri=nullptr;int method=0;esp_err_t (*handler)(httpd_req_t*)=nullptr;void* user_ctx=nullptr;};
constexpr int HTTP_GET=0,HTTP_POST=1;
constexpr int HTTPD_403_FORBIDDEN=403,HTTPD_400_BAD_REQUEST=400,HTTPD_500_INTERNAL_SERVER_ERROR=500;
constexpr int HTTPD_SOCK_ERR_TIMEOUT=-2;
extern "C" esp_err_t httpd_resp_set_type(httpd_req_t*,const char*);
extern "C" esp_err_t httpd_resp_set_hdr(httpd_req_t*,const char*,const char*);
extern "C" esp_err_t httpd_resp_sendstr(httpd_req_t*,const char*);
extern "C" esp_err_t httpd_resp_send_err(httpd_req_t*,int,const char*);
extern "C" esp_err_t httpd_req_get_hdr_value_str(httpd_req_t*,const char*,char*,size_t);
extern "C" int httpd_req_recv(httpd_req_t*,char*,size_t);
extern "C" esp_err_t httpd_start(httpd_handle_t*,const httpd_config_t*);
extern "C" esp_err_t httpd_register_uri_handler(httpd_handle_t,const httpd_uri_t*);
extern "C" esp_err_t httpd_stop(httpd_handle_t);
