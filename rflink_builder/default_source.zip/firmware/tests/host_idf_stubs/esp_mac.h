#pragma once
#include <cstdint>
#include "esp_err.h"
constexpr int ESP_MAC_WIFI_STA=0;
extern "C" esp_err_t esp_read_mac(uint8_t*,int);
